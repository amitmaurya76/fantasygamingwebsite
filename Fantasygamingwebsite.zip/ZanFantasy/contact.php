<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css/tailwind.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        body {
            background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
        }
        .rounded {
            border-radius: 1.25rem;
        }
    </style>
</head>
<body class="bg-gray-50">
<?php include 'loader.php'; ?>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
            </div>

            <!-- Contact Card -->
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-6 text-gray-200 text-sm max-h-[70vh] overflow-y-auto">
                <h2 class="text-xl font-bold text-center mb-2">📞 Contact Us</h2>
                <p class="text-green-400 text-center font-semibold mb-4">We're here to help you 24/7</p>

                <h3 class="text-green-400 font-semibold mb-1">✉️ Email Support</h3>
                <p class="mb-2">Write to us at: <span class="text-green-400 font-semibold">support@zanthium.com</span></p>

                <h3 class="text-green-400 font-semibold mb-1">📱 Call Support</h3>
                <p class="mb-2">Call us anytime at: <span class="text-green-400 font-semibold">+91 9876543210</span></p>

                <h3 class="text-green-400 font-semibold mb-1">⚡ Fastest Support</h3>
                <p class="mb-2">Use the in-app <span class="text-green-400 font-semibold">Support Section</span> for faster resolution of your queries directly from your account.</p>

                <p class="text-xs text-gray-300 mt-3 text-center">We aim to resolve your issues quickly so you can get back to enjoying your fantasy leagues.</p>

                <div class="text-center mt-4">
                    <a href="mailto:support@zanthium.com" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full text-sm shadow transition">📧 Send Email</a>
                </div>
            </div>

            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>

    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
