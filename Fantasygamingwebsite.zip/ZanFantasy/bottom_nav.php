<!-- Bottom Navigation -->
<div class="fixed bottom-0 w-full bg-gray-800 border-t border-gray-700 flex justify-around text-center py-2 lg:hidden">
  <a href="play-game.php" class="flex flex-col items-center text-green-500">🏠<span class="text-xs">Leagues</span></a>
  <a href="myleagues.php" class="flex flex-col items-center text-gray-400">⭐<span class="text-xs">My Leagues</span></a>
  <a href="wallet.php" class="flex flex-col items-center text-gray-400">💰<span class="text-xs">Wallet</span></a>
  <a href="profile.php" class="flex flex-col items-center text-gray-400">🙍‍♂️<span class="text-xs">You</span></a>
  <a href="more.php" class="flex flex-col items-center text-gray-400">⋯<span class="text-xs">More</span></a>
</div>
