<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Edit Profile - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
</head>
<body class="bg-gradient-to-br from-gray-800 to-gray-900 min-h-screen flex flex-col">

<?php include 'loader.php'; ?>

<!-- Page Container -->
<div class="flex flex-1 flex-col items-center justify-center p-4">

    <!-- Card -->
    <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl shadow-lg w-full max-w-md p-6">

        <!-- Logo -->
        <div class="flex justify-center mb-4">
            <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12 object-contain">
        </div>

        <!-- Heading -->
        <h2 class="text-xl font-bold text-center text-white mb-2">🙍‍♂️ Edit Your Profile</h2>
        <p class="text-sm text-gray-300 text-center mb-4">Update your personal details to keep your profile current.</p>

        <!-- Profile Edit Form -->
        <form  class="space-y-4">

            <!-- Profile Picture Upload -->
            <div class="flex flex-col items-center">
                <img src="image/user.png" alt="Profile Picture" class="w-24 h-24 rounded-full object-cover shadow mb-2">
                <label class="text-sm text-gray-300 cursor-pointer bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded transition">
                    📷 Change Photo
                    <input type="file" name="profile_picture" class="hidden">
                </label>
            </div>

            <!-- Name -->
            <div>
                <label class="text-gray-300 text-sm">Name</label>
                <input type="text" name="name" value="Amit Maurya" class="w-full mt-1 p-2 rounded bg-gray-800 text-white border border-gray-600 focus:outline-none focus:ring focus:border-green-500" required>
            </div>

            <!-- Email -->
            <div>
                <label class="text-gray-300 text-sm">Email</label>
                <input type="email" name="email" value="amit@example.com" class="w-full mt-1 p-2 rounded bg-gray-800 text-white border border-gray-600 focus:outline-none focus:ring focus:border-green-500" required>
            </div>

            <!-- Phone -->
            <div>
                <label class="text-gray-300 text-sm">Phone</label>
                <input type="tel" name="phone" value="+91 9876543210" class="w-full mt-1 p-2 rounded bg-gray-800 text-white border border-gray-600 focus:outline-none focus:ring focus:border-green-500" required>
            </div>

            <!-- Referral Code (readonly) -->
            <div>
                <label class="text-gray-300 text-sm">Referral Code</label>
                <input type="text" name="referral_code" value="AMIT1234" readonly class="w-full mt-1 p-2 rounded bg-gray-800 text-gray-400 border border-gray-600 cursor-not-allowed">
            </div>

            <!-- Save Button -->
            <a href="404.php">
            <button  class="w-full mt-1 bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-semibold transition">Save Changes</button>
            </a>
            <a href="profile.php" class="block text-center text-sm text-gray-400 hover:text-gray-200 mt-2 transition">← Back to Profile</a>
        </form>
    </div>
</div>

<?php include 'bottom_nav.php'; ?>

</body>
</html>
