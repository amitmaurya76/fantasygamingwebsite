<?php
session_start();
require 'razorpay/Razorpay.php';
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
include 'db.php';

header('Content-Type: application/json');

$api = new Api('rzp_test_yourkey', 'your_secret');

$payment_id = $_POST['payment_id'];
$order_id = $_POST['order_id'];
$signature = $_POST['signature'];
$amount = (int)$_POST['amount'];

$attributes = [
    'razorpay_order_id' => $order_id,
    'razorpay_payment_id' => $payment_id,
    'razorpay_signature' => $signature
];

try {
    $api->utility->verifyPaymentSignature($attributes);

    $user_id = $_SESSION['user_id'];

    $pdo->prepare("INSERT INTO transactions (user_id, amount, mode, status, order_id, created_at) VALUES (?, ?, 'Razorpay', 'Success', ?, NOW())")->execute([$user_id, $amount, $order_id]);

    // Auto-enroll user in contest logic here if needed

    echo json_encode(['status' => 'success']);
} catch (SignatureVerificationError $e) {
    echo json_encode(['status' => 'error', 'message' => 'Signature verification failed']);
}
