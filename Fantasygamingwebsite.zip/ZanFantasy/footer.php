<!-- footer.php -->
<footer class="bg-gray-900 text-gray-300 py-10">
  <div class="max-w-7xl mx-auto px-4">
    <div class="flex flex-col items-center space-y-6 text-center">
      <img src="image/logo-white.png" alt="Zanthium Logo" class="rounded w-28 shadow" />
      <!-- <h2 class="text-xl font-semibold">Zanthium</h2> -->
      <p class="max-w-md text-sm">Discover why Zanthium is a hit with over 1 Million+ players. Play fantasy sports like never before.</p>
    </div>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-8 mt-10  p-4 text-left text-sm">
      <div>
        <h3 class="text-lg font-semibold mb-2">COMPANY</h3>
        <ul class="space-y-1">
          <li><a href="#" class="hover:text-yellow-400">About Us</a></li>
          <li><a href="#" class="hover:text-yellow-400">Download App</a></li>
          <li><a href="#" class="hover:text-yellow-400">How to Play</a></li>
          <li><a href="#" class="hover:text-yellow-400">Refer And Earn</a></li>
          <li><a href="#" class="hover:text-yellow-400">Blog</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-lg font-semibold mb-2">SUPPORT</h3>
        <ul class="space-y-1">
          <li><a href="#" class="hover:text-yellow-400">Pointing System</a></li>
          <li><a href="#" class="hover:text-yellow-400">Fair Play</a></li>
          <li><a href="#" class="hover:text-yellow-400">Contact Us</a></li>
          <li><a href="#" class="hover:text-yellow-400">Cricket Players</a></li>
        </ul>
      </div>
      <div>
        <h3 class="text-lg font-semibold mb-2">PRODUCTS</h3>
        <ul class="space-y-1">
          <li><a href="#" class="hover:text-yellow-400">Fantasy Cricket</a></li>
          <li><a href="#" class="hover:text-yellow-400">Fantasy Kabaddi App</a></li>
          <li><a href="#" class="hover:text-yellow-400">Live Cricket Score</a></li>
          <li><a href="#" class="hover:text-yellow-400">Cricket Upcoming</a></li>
          <li><a href="#" class="hover:text-yellow-400">Get it on Play Store</a></li>
        </ul>
      </div>
      <!-- <div>
        <h3 class="text-lg font-semibold mb-2">PAYMENT PARTNERS</h3>
        <div class="space-y-2">
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Paytm_logo.png/320px-Paytm_logo.png" alt="Paytm" class="h-8" />
          <img src="https://via.placeholder.com/150x40?text=Safe+Checkout" alt="Safe Checkout" class="h-8" />
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Cashfree_Logo_Full.png/320px-Cashfree_Logo_Full.png" alt="Cashfree Payments" class="h-8" />
        </div>
      </div> -->
      <div>
        <h3 class="text-lg font-semibold mb-2">SOCIAL MEDIA</h3>
        <ul class="space-y-1">
          <li><a href="#" class="hover:text-yellow-400">Facebook</a></li>
          <li><a href="#" class="hover:text-yellow-400">Instagram</a></li>
          <li><a href="#" class="hover:text-yellow-400">Twitter</a></li>
          <li><a href="#" class="hover:text-yellow-400">YouTube</a></li>
        </ul>
      </div>
    </div>
    <p class="text-center text-xs text-gray-400 mt-10">© 2025 Zanthium. All rights reserved.</p>
  </div>
</footer>