<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="css\tailwind.min.css" rel="stylesheet"/>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        .rounded {
            border-radius: 1.25rem;
        }
        body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}

    </style>
</head>
<body class="bg-gray-50 text-gray-100">
<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">
    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >


            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="logo" class="h-full object-contain">
            </div>

            <!-- Profile Header -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-6 text-center shadow-lg">
            <img src="image/user.png" alt="User" class="w-24 h-24 mx-auto rounded-full border-4 border-green-500 mb-2">
            <h1 class="text-xl font-bold">Amit Maurya</h1>
            <p class="text-sm text-gray-300">📱 +91 94589 02989</p>
            <p class="text-green-400 text-xs mt-1">✅ KYC Verified</p>
            <a href="edit_profile.php">
            <button class="mt-3 bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded-full text-sm transition">✏️ Edit Profile</button>
            </a>
        </div>

        <!-- Level and XP -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-4 mt-4 shadow">
            <div class="flex items-center justify-between mb-1">
                <span class="text-sm">Level 5</span>
                <span class="text-sm text-green-400">2500 / 3000 XP</span>
            </div>
            <div class="w-full bg-gray-600 rounded-full h-2.5">
                <div class="bg-green-500 h-2.5 rounded-full" style="width: 83%;"></div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-2 gap-4 mt-4">
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-4 text-center shadow">
                <p class="text-gray-300 text-sm">Total Winnings</p>
                <p class="text-green-400 font-bold text-lg">₹ 5,000</p>
            </div>
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-4 text-center shadow">
                <p class="text-gray-300 text-sm">Contests Joined</p>
                <p class="text-green-400 font-bold text-lg">23</p>
            </div>
        </div>

        <!-- Badges -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-4 mt-4 shadow">
            <h2 class="text-sm font-semibold mb-2">🏅 Badges</h2>
            <div class="flex flex-wrap gap-2 justify-center">
                <span class="bg-yellow-500 text-black px-2 py-0.5 rounded-full text-xs">Top Scorer</span>
                <span class="bg-blue-500 text-white px-2 py-0.5 rounded-full text-xs">Early Joiner</span>
                <span class="bg-green-500 text-white px-2 py-0.5 rounded-full text-xs">Streak 5 Days</span>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-4 mt-4 shadow">
            <h2 class="text-sm font-semibold mb-2">📝 Recent Activity</h2>
            <ul class="text-xs space-y-1">
                <li>🏆 Joined Mega League - Won ₹500</li>
                <li>⚔️ Joined Premier League - Entry ₹49</li>
                <li>🏆 Won ₹100 in Daily League</li>
                <li>🏆 Joined Weekend Challenge - Won ₹200</li>
            </ul>
        </div>

        <!-- Winnings Chart -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-4 mt-4 shadow">
            <h2 class="text-sm font-semibold mb-2">📈 Winnings Trend</h2>
            <canvas id="winningsChart" class="w-full"></canvas>
        </div>

        <!-- Referral Section -->
        <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl p-4 mt-4 text-center shadow">
            <h2 class="text-sm font-semibold mb-2">Invite Friends & Earn</h2>
            <p class="text-green-400 font-mono mb-2">Referral Code: AMIT1234</p>
            <a href="404.php">
                <button class="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded-full text-sm transition"> Share Now</button>
            </a> 
        </div>
            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
            <?php include 'DownloadSection.php'; ?>

    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
        const ctx = document.getElementById('winningsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Winnings (₹)',
                    data: [0, 200, 500, 150, 300, 400, 100],
                    borderColor: 'rgb(34, 197, 94)',
                    backgroundColor: 'rgba(34, 197, 94, 0.2)',
                    tension: 0.4
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                },
                plugins: {
                    legend: { display: false }
                }
            }
        });
    </script>

</body>
</html>
