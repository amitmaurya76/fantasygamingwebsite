<?php
session_start();
require 'razorpay/Razorpay.php';
use Razorpay\Api\Api;
header('Content-Type: application/json');

$amount = (int)$_POST['amount'] * 100; // paise

$api = new Api('rzp_test_yourkey', 'your_secret');
$order = $api->order->create([
    'receipt' => 'rcptid_' . time(),
    'amount' => $amount,
    'currency' => 'INR'
]);

echo json_encode(['order_id' => $order['id'], 'amount' => $order['amount']]);
