<?php
session_start();
include 'db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Login required']);
    exit();
}

$user_id = $_SESSION['user_id'];
$amount = (int)$_POST['amount'];

// Check wallet balance
$stmt = $pdo->prepare("SELECT wallet_balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$wallet_balance = $stmt->fetchColumn();

if ($wallet_balance >= $amount) {
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?")->execute([$amount, $user_id]);
        $pdo->prepare("INSERT INTO transactions (user_id, amount, mode, status, created_at) VALUES (?, ?, 'Wallet', 'Success', NOW())")->execute([$user_id, $amount]);

        // Auto-enroll user in contest logic here if needed

        $pdo->commit();
        echo json_encode(['status' => 'success']);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Transaction failed']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Insufficient wallet balance']);
}
