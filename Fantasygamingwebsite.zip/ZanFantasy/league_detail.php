<?php
// league_detail.php
// Optionally fetch dynamic data using ?id=123 if you add DB connection later
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>League Details - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <link href="css\tailwind.min.css" rel="stylesheet"/>
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.2);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
            background: #0f172a;
        }
        #sidebar a:hover {
            background: black;
            font-size: 2rem;
            line-height: 2rem;
            border-radius: 50px;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-800 to-gray-900 min-h-screen">

<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content -->
    <div class="flex-1 flex justify-center items-start p-4">
        <div class="max-w-md w-full bg-gradient-to-r from-gray-800 to-gray-700 rounded-3xl shadow-lg p-6 border border-gray-700">

            <!-- Header -->
            <div class="flex justify-center mb-4">
                <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12 object-contain" />
            </div>

            <h2 class="text-xl font-bold text-center text-white mb-4">🏆 League Details</h2>

            <!-- League Information Card -->
            <div class="bg-gray-900 rounded-lg p-4 mb-4 text-gray-200 space-y-2">
                <div class="flex justify-between">
                    <span>League:</span>
                    <span class="font-semibold">Tamil Nadu Premier League</span>
                </div>
                <div class="flex justify-between">
                    <span>Status:</span>
                    <span class="font-semibold text-green-400">Live</span>
                </div>
                <div class="flex justify-between">
                    <span>Prize Pool:</span>
                    <span class="font-semibold text-green-400">₹1,00,000</span>
                </div>
                <div class="flex justify-between">
                    <span>Your Rank:</span>
                    <span class="font-semibold text-yellow-400">#15</span>
                </div>
                <div class="flex justify-between">
                    <span>Entries:</span>
                    <span class="font-semibold text-gray-300">3123</span>
                </div>
            </div>

            <!-- Teams Display -->
            <div class="flex justify-around items-center my-4">
                <div class="flex flex-col items-center">
                    <img src="image/team1.png" alt="Team A" class="w-16 h-16 rounded-full border border-gray-600">
                    <span class="text-xs text-gray-200 mt-1">CPK</span>
                </div>
                <span class="text-gray-300 font-semibold">VS</span>
                <div class="flex flex-col items-center">
                    <img src="image/team2.png" alt="Team B" class="w-16 h-16 rounded-full border border-gray-600">
                    <span class="text-xs text-gray-200 mt-1">MDR</span>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="space-y-2">
                <a href="404.php" class="block w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg text-center font-semibold transition">
                    Join Another Contest
                </a>
                <a href="wallet.php" class="block w-full bg-gray-700 hover:bg-gray-600 text-gray-100 py-2 rounded-lg text-center font-semibold transition">
                    View Wallet & Winnings
                </a>
            </div>

            <p class="text-xs text-gray-400 text-center mt-3">Track your performance and join more contests to maximize your winnings on Zanthium Fantasy.</p>
        </div>
    </div>

</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
