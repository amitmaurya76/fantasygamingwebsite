<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>My Leagues - Zanthium</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link href="css/style.css" rel="stylesheet" />
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
</head>
<style>
      #sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }
    body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
/* === Base Font Scaling for Consistent UX === */
html {
    font-size: 16px;
    scroll-behavior: smooth;
}

@media (max-width: 1280px) { html { font-size: 15px; } }
@media (max-width: 1024px) { html { font-size: 14px; } }
@media (max-width: 768px) { html { font-size: 13px; } }
@media (max-width: 480px) { html { font-size: 12px; } }
@media (min-width: 1536px) { html { font-size: 18px; } }
@media (min-width: 2560px) { html { font-size: 20px; } }
@media (min-width: 3840px) { html { font-size: 24px; } }

/* === Sidebar Styling === */
#sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }

@media (min-width: 1024px) {
    
    #sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }
}
@media (min-width: 3840px) {
    
    #sidebar {
      height: 550px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }
}


/* === Main Content Container === */
.main-content {
    max-width: 90%;
    margin: auto;
    padding: 1rem;
}
@media (min-width: 640px) { .main-content { max-width: 540px; } }
@media (min-width: 768px) { .main-content { max-width: 640px; } }
@media (min-width: 1024px) { .main-content { max-width: 768px; } }
@media (min-width: 1280px) { .main-content { max-width: 1024px; } }
@media (min-width: 1536px) { .main-content { max-width: 1280px; } }
@media (min-width: 2560px) { .main-content { max-width: 1600px; } }
@media (min-width: 3840px) { .main-content { max-width: 1900px; } }


.scroll-smooth {
    scroll-behavior: smooth;
}
.no-scrollbar::-webkit-scrollbar {
    display: none;
}
.no-scrollbar {
    -ms-overflow-style: none;
    scrollbar-width: none;
}
</style>
<body class="bg-gray-50">
<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">
  <!-- Sidebar -->
      <?php include 'sidebar.php'; ?>


  <!-- Main Content -->
  <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
    <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >

      <div class="w-full h-12 mb-4 flex items-center">
        <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
      </div>

      <div class=" rounded-lg shadow p-4 mb-4" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
        <h2 class="text-center text-sm font-semibold text-gray-50">My Joined Contests</h2>
      </div>

      <div id="leaguesList" class="space-y-3 overflow-y-auto max-h-[70vh] pr-1">

    <a href="league_detail.php" class="block">
        <div class="bg-white rounded-lg shadow p-4 hover:scale-[1.02] transition transform duration-200" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
            <div class="flex justify-between items-center mb-2">
                <span class="bg-green-700 text-green-50 text-xs px-2 py-0.5 rounded">Live</span>
                <span class="text-xs text-gray-300">Tamil Nadu Premier League</span>
            </div>
            <div class="flex justify-between items-center">
                <div class="flex flex-col items-center">
                    <img src="image/team1.png" alt="CPK" class="w-12 h-12 object-contain" />
                    <span class="text-xs mt-1 text-gray-200">CPK</span>
                </div>
                <div class="text-red-500 font-semibold">Live</div>
                <div class="flex flex-col items-center">
                    <img src="image/team2.png" alt="MDR" class="w-12 h-12 object-contain" />
                    <span class="text-xs mt-1 text-gray-200">MDR</span>
                </div>
            </div>
            <div class="flex justify-between mt-1 text-xs">
                <span class="text-gray-200">Your Rank: 15</span>
                <span class="bg-green-700 px-2 py-0.5 rounded">Prize Pool: ₹1,00,000</span>
            </div>
        </div>
    </a>

    <a href="league_detail.php" class="block">
        <div class="bg-white rounded-lg shadow p-4 hover:scale-[1.02] transition transform duration-200" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
            <div class="flex justify-between items-center mb-2">
                <span class="bg-yellow-500 text-yellow-50 text-xs px-2 py-0.5 rounded">Upcoming</span>
                <span class="text-xs text-gray-300">Premier League</span>
            </div>
            <div class="flex justify-between items-center">
                <div class="flex flex-col items-center">
                    <img src="image/team3.png" alt="ARS" class="w-12 h-12 object-contain" />
                    <span class="text-xs mt-1 text-gray-200">ARS</span>
                </div>
                <div class="text-center">
                    <span class="block text-xs text-gray-300">Time Left</span>
                    <span id="countdown" class="text-green-400 font-bold">1h 0m 0s</span>
                </div>
                <div class="flex flex-col items-center">
                    <img src="image/team4.png" alt="CHE" class="w-12 h-12 object-contain" />
                    <span class="text-xs mt-1 text-gray-200">CHE</span>
                </div>
            </div>
            <div class="flex justify-between mt-1 text-xs">
                <span class="text-gray-200">Entries: 3123</span>
                <span class="bg-green-700 px-2 py-0.5 rounded">Prize Pool: ₹3,00,000</span>
            </div>
        </div>
    </a>

</div>


      <div class="flex justify-center mt-4">
        <button id="loadMoreLeagues" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition text-sm">Load More</button>
      </div>
    </div>

        <?php include 'DownloadSection.php'; ?>

  </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
document.getElementById('loadMoreLeagues').addEventListener('click', function() {
  const leaguesList = document.getElementById('leaguesList');
  const newLeague = document.createElement('div');
  newLeague.className = "bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4" ;
  newLeague.innerHTML = `
    <div class="flex justify-between items-center mb-2">
      <span class="bg-blue-700 text-blue-50 text-xs px-2 py-0.5 rounded">Completed</span>
      <span class="text-xs text-gray-500">Basketball Series</span>
    </div>
    <div class="flex justify-between items-center">
      <div class="flex flex-col items-center">
        <img src="image/team5.png" alt="TEAM A" class="w-12 h-12 object-contain" />
        <span class="text-xs mt-1">TEAM A</span>
      </div>
      <div class="text-gray-50 font-semibold ">Completed</div>
      <div class="flex flex-col items-center">
        <img src="image/team4.png" alt="TEAM B" class="w-12 h-12 object-contain" />
        <span class="text-xs mt-1">TEAM B</span>
      </div>
    </div>
    <div class="flex justify-between mt-1 text-xs">
      <span class="text-gray-60">Rank: 55</span>
      <span class="bg-green-700 px-2 py-0.5 rounded">Winnings: ₹500</span>
    </div>`;
  leaguesList.appendChild(newLeague);
  leaguesList.scrollTo({ top: leaguesList.scrollHeight, behavior: 'smooth' });
});
</script>
<script>
function startCountdown(elementId, totalSeconds) {
    const countdownEl = document.getElementById(elementId);
    const interval = setInterval(() => {
        if (totalSeconds <= 0) {
            clearInterval(interval);
            countdownEl.textContent = 'Started';
            countdownEl.classList.remove('text-green-400');
            countdownEl.classList.add('text-red-500');
            return;
        }
        const h = Math.floor(totalSeconds / 3600);
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = totalSeconds % 60;
        countdownEl.textContent = `${h} h ${m} m ${s} s`;
        totalSeconds--;
    }, 1000);
}
startCountdown('countdown', 60 * 60);
</script>

</body>
</html>
