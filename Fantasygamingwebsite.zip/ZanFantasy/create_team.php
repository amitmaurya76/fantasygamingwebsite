<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Create Team - Zanthium</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<link href="css\tailwind.min.css" rel="stylesheet"/>
<link rel="icon" href="image/favicon.ico" type="image/x-icon">
<style>
.gradient-header { background: linear-gradient(90deg, #0f2027, #203a43, #2c5364); }
.selected { border: 2px solid #10b981; background-color: rgba(16, 185, 129, 0.1); }
#sidebar {
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
#sidebar a:hover {
  border-radius: 50px;
  background: black;
  font-size: 2rem;
  line-height: 2rem;
}body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col lg:flex-row">
<?php include 'loader.php'; ?>

<!-- Sidebar -->
    <?php include 'sidebar.php'; ?>


<!-- Main Content -->
<div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
<div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >

    <!-- Logo -->
    <div class="w-full h-12 mb-4 flex items-center justify-center">
      <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
    </div>

    <!-- Match Header -->
    <div class="gradient-header p-4 rounded-lg text-white flex justify-between items-center mb-4">
      <div class="flex items-center space-x-4">
        <div class="flex flex-col items-center">
          <img src="image/team1.png" alt="WLS" class="w-12 h-12 rounded-full border border-white">
          <span class="text-xs">Team 1</span>
        </div>
        <span>vs</span>
        <div class="flex flex-col items-center">
          <img src="image/team2.png" alt="CBR" class="w-12 h-12 rounded-full border border-white">
          <span class="text-xs">Team 2</span>
        </div>
      </div>
      <div class="text-center">
        <span class="block text-xs text-gray-300">Time Left</span>
        <span id="countdown" class="text-green-400 font-bold">0h 9m</span>
      </div>
    </div>

    <!-- Tabs -->
    <div class="grid grid-cols-4 gap-1 bg-gray-800 rounded-lg p-1 mb-4 text-xs font-semibold shadow-inner">

  <button id="tab-WK" onclick="setActiveTab('WK')" class="py-2 text-center rounded transition duration-300 border-b-2 border-green-400 text-green-400 flex items-center justify-center gap-1">
    WK <span id="count-WK" class="ml-1 bg-green-500 text-white rounded-full px-1 text-xs">0</span>
  </button>

  <button id="tab-BAT" onclick="setActiveTab('BAT')" class="py-2 text-center rounded transition duration-300 text-gray-400 flex items-center justify-center gap-1">
    BAT <span id="count-BAT" class="ml-1 bg-gray-600 text-white rounded-full px-1 text-xs">0</span>
  </button>

  <button id="tab-AR" onclick="setActiveTab('AR')" class="py-2 text-center rounded transition duration-300 text-gray-400 flex items-center justify-center gap-1">
    AR <span id="count-AR" class="ml-1 bg-gray-600 text-white rounded-full px-1 text-xs">0</span>
  </button>

  <button id="tab-BOWL" onclick="setActiveTab('BOWL')" class="py-2 text-center rounded transition duration-300 text-gray-400 flex items-center justify-center gap-1">
    BOWL <span id="count-BOWL" class="ml-1 bg-gray-600 text-white rounded-full px-1 text-xs">0</span>
  </button>

</div>

    <!-- Player List -->
    <div id="playerList" class="space-y-2"></div>

    <!-- Confirm Button -->
    <button id="confirmTeam" class="mt-4 w-full py-2 bg-green-600 hover:bg-green-700 rounded text-white font-bold" disabled>Confirm Team (0/11)</button>

  </div>

  <!-- Right Download Section (Desktop) -->
  <div class="hidden lg:flex flex-col justify-center items-center p-4 w-full lg:w-96">
      <img src="image/appui.png" alt="Player" class="h-3/5 w-full mb-4 rounded" />
    <h2 class="text-xl font-bold text-center text-gray-50">Play Zanthium Fantasy on Mobile</h2>
    <div class="flex mt-4 space-x-2">
      <img src="image/image.png" alt="Download Android" class="w-28 rounded" />
      <img src="image/image1.png" alt="Download iOS" class="w-28 rounded" />
    </div>
  </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
const categories = {
WK: Array.from({length: 4}, (_, i) => ({name: `Player WK${i+1}`, image: `image/player${i+1}.png`})),
BAT: Array.from({length: 7}, (_, i) => ({name: `Player BAT${i+1}`, image: `image/player${i+5}.png`})),
AR: Array.from({length: 5}, (_, i) => ({name: `Player AR${i+1}`, image: `image/player${i+6}.png`})),
BOWL: Array.from({length: 8}, (_, i) => ({name: `Player BOWL${i+1}`, image: `image/player${i+1}.png`}))
};
const counts = { WK: 0, BAT: 0, AR: 0, BOWL: 0, total: 0 };
let selectedPlayers = [];
const maxPlayers = 11;
function updateCounts() {
  ['WK', 'BAT', 'AR', 'BOWL'].forEach(cat => {
    document.getElementById(`count-${cat}`).innerText = counts[cat];
  });
  document.getElementById('confirmTeam').innerText = `Confirm Team (${counts.total}/11)`;
  document.getElementById('confirmTeam').disabled = counts.total !== 11;
}
function renderPlayers(category) {
  const list = document.getElementById('playerList');
  list.innerHTML = '';
  categories[category].forEach(player => {
    const card = document.createElement('div');
    card.className = 'bg-gray-800 rounded p-3 flex items-center justify-between cursor-pointer';
    card.innerHTML = `
      <div class='flex items-center space-x-3'>
        <img src='${player.image}' alt='${player.name}' class='w-10 h-10 rounded-full border border-gray-700'>
        <span class ='text-white '>${player.name}</span>
      </div>
      <span class='text-green-400'>+ Select</span>`;
    card.addEventListener('click', () => {
      if (!selectedPlayers.includes(player) && counts.total < maxPlayers) {
        selectedPlayers.push(player);
        counts[category]++;
        counts.total++;
        card.classList.add('selected');
        card.querySelector('span:last-child').innerText = '✓ Selected';
      } else if (selectedPlayers.includes(player)) {
        selectedPlayers = selectedPlayers.filter(p => p !== player);
        counts[category]--;
        counts.total--;
        card.classList.remove('selected');
        card.querySelector('span:last-child').innerText = '+ Select';
      }
      updateCounts();
    });
    list.appendChild(card);
  });
}
['WK', 'BAT', 'AR', 'BOWL'].forEach(cat => {
  document.getElementById(`tab-${cat}`).addEventListener('click', () => {
    ['WK', 'BAT', 'AR', 'BOWL'].forEach(c => {
      document.getElementById(`tab-${c}`).classList.remove('text-green-400', 'border-green-400');
      document.getElementById(`tab-${c}`).classList.add('text-gray-400');
    });
    document.getElementById(`tab-${cat}`).classList.add('text-green-400', 'border-green-400');
    document.getElementById(`tab-${cat}`).classList.remove('text-gray-400');
    renderPlayers(cat);
  });
});
document.getElementById('confirmTeam').addEventListener('click', () => {
  if (counts.total === 11) {
    window.location.href = 'captain_vc.php';
  } else {
    alert('Please select 11 players to continue.');
  }
});
renderPlayers('WK');
updateCounts();
</script>
<script>
function setActiveTab(tab) {
    const tabs = ['WK', 'BAT', 'AR', 'BOWL'];

    tabs.forEach(t => {
        const button = document.getElementById(`tab-${t}`);
        const badge = document.getElementById(`count-${t}`);

        if (t === tab) {
            button.classList.add('text-green-400', 'border-b-2', 'border-green-400');
            button.classList.remove('text-gray-400');
            badge.classList.add('bg-green-500');
            badge.classList.remove('bg-gray-600');
        } else {
            button.classList.remove('text-green-400', 'border-b-2', 'border-green-400');
            button.classList.add('text-gray-400');
            badge.classList.remove('bg-green-500');
            badge.classList.add('bg-gray-600');
        }
    });
}
</script>
<script>
// Countdown Timer
let countdownSeconds = 9 * 60;
const countdownEl = document.getElementById('countdown');
const interval = setInterval(() => {
  if (countdownSeconds <= 0) {
    clearInterval(interval);
    countdownEl.textContent = 'Started';
    return;
  }
  const m = Math.floor(countdownSeconds / 60);
  const s = countdownSeconds % 60;
  countdownEl.textContent = `${m}m ${s}s`;
  countdownSeconds--;
}, 1000);
</script>
</body>
</html>
