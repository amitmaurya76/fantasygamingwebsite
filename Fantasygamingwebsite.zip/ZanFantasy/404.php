<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found | Zanthium</title>
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
      <link href="css\tailwind.min.css" rel="stylesheet"/>

    <style>
        .animate-bounce-custom {
            animation: bounce 2s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-800 to-gray-900 text-white flex items-center justify-center min-h-screen">
    <div class="text-center p-6">
        <img src="image/logo-white.png" alt="Zanthium Logo" class="w-28 mx-auto mb-4 animate-bounce-custom">
        <h1 class="text-6xl font-bold text-green-400 mb-4">404</h1>
        <h2 class="text-2xl font-semibold mb-2">Oops! Page Not Found</h2>
        <p class="text-gray-300 mb-6">The page you are looking for doesn't exist or has been moved.</p>
        <div class="mt-8">
            <img src="image/404-player.png" alt="Lost Player" class="w-48 mx-auto">
        </div>
     <a href="play-game.php" class="bg-green-500 hover:bg-green-600 transition text-white px-6 py-3 rounded-full font-semibold inline-block"> Go Back Home</a>

    </div>
</body>
</html>
