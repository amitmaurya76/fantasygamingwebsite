<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Terms & Conditions - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/tailwind.min.css" rel="stylesheet"/>
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        body {
            background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
        }
        .accordion-header { cursor: pointer; }
        .accordion-content { max-height: 0; overflow: hidden; transition: max-height 0.3s ease; }
        .accordion-content.open { max-height: 500px; }
        @media print {
            #sidebar, .print-hidden, .download-prompt { display: none; }
            body { background: white !important; color: black !important; }
        }
    </style>
</head>
<body class="bg-gray-50 transition-colors duration-300" id="body">

<?php include 'loader.php'; ?>

<!-- Accept Modal -->
<div id="acceptModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-70 z-50">
    <div class="bg-white rounded-lg p-6 max-w-sm text-center shadow-lg">
        <h2 class="text-lg font-semibold mb-4">Accept Terms & Conditions</h2>
        <p class="text-sm mb-4">Please read and accept our Terms & Conditions before continuing to use Zanthium.</p>
        <button onclick="acceptTerms()" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full">Accept & Continue</button>
    </div>
</div>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo and Theme Toggle -->
            <div class="w-full h-12 mb-4 flex items-center justify-between">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
                <button onclick="toggleTheme()" class="text-xs bg-gray-800 text-white px-2 py-1 rounded print-hidden">🌓 Toggle Theme</button>
            </div>

            <!-- Terms & Conditions Card -->
           <!-- Terms & Conditions Card -->
<div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-2xl shadow-xl p-5 text-gray-200 text-sm print:bg-white print:text-black">
    <div class="flex items-center justify-center mb-4">
        <span class="text-2xl">📜</span>
        <h2 class="text-xl font-bold ml-2">Terms & Conditions</h2>
    </div>
    <p class="text-center text-xs mb-5 text-gray-300">Tap each section to expand and view details.</p>

    <div class="space-y-2" id="accordion">
        <!-- Accordion Template -->
        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>User Eligibility</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                You must be 18+ and legally eligible to participate in fantasy sports in your state of residence.
            </div>
        </div>

        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>Account Responsibility</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                You are responsible for maintaining the confidentiality of your Zanthium account and password.
            </div>
        </div>

        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>KYC & Withdrawals</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                KYC verification is mandatory for withdrawals to ensure secure transactions and compliance with laws.
            </div>
        </div>

        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>Fraud Prevention</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                Zanthium reserves the right to suspend or terminate accounts in case of suspected fraudulent activities.
            </div>
        </div>

        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>Policy Updates</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                Terms and policies may be updated periodically. Continued use of Zanthium means you agree to the updated terms.
            </div>
        </div>

        <div class="accordion-item border border-gray-600 rounded-lg overflow-hidden">
            <button class="accordion-header flex justify-between items-center w-full px-4 py-3 bg-gray-900 hover:bg-gray-800 transition focus:outline-none">
                <span>Contact Us</span>
                <span class="indicator">➕</span>
            </button>
            <div class="accordion-content hidden text-xs text-gray-300 px-4 py-2">
                For queries, email us at <span class="text-green-400">support@zanthium.com</span>.
            </div>
        </div>
    </div>
</div>


            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center download-prompt">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>
    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<!-- Scripts -->
<script>
document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
        const content = header.nextElementSibling;
        content.classList.toggle('open');
        const icon = header.querySelector('span:last-child');
        icon.textContent = content.classList.contains('open') ? '➖' : '➕';
    });
});

function toggleTheme() {
    const body = document.getElementById('body');
    body.classList.toggle('bg-gray-50');
    body.classList.toggle('bg-gray-900');
}

function acceptTerms() {
    document.getElementById('acceptModal').style.display = 'none';
}
</script>
<script>
// Improved Accordion Functionality
document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
        const currentContent = header.nextElementSibling;
        const isVisible = !currentContent.classList.contains('hidden');

        // Close all
        document.querySelectorAll('.accordion-content').forEach(content => content.classList.add('hidden'));
        document.querySelectorAll('.indicator').forEach(indicator => indicator.textContent = '➕');

        // Toggle current
        if (!isVisible) {
            currentContent.classList.remove('hidden');
            header.querySelector('.indicator').textContent = '➖';
        }
    });
});
</script>

</body>
</html>
