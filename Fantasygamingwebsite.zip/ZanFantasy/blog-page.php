<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Blog - Zanthium</title>
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<style>
    .card-hover:hover {
      transform: translateY(-5px) scale(1.02);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
  </style>
<body class="bg-gray-900 text-white min-h-screen flex flex-col">
<?php include 'header.php'; ?>

<section class="relative flex flex-col items-center justify-center text-center py-32 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
  <div class="bg-black bg-opacity-70 p-8 rounded-xl w-full max-w-2xl mx-auto animate-fadeInUp">
    <h1 class="text-4xl md:text-5xl font-extrabold leading-tight mb-4 text-yellow-400"> Blog</h1>
    <p class="text-lg md:text-xl text-gray-300">Stay ahead in your fantasy contests with strategies, player analysis, and game updates from the experts at Zanthium.</p>
  </div>
</section>

<main class="flex-grow pt-16 px-4 text-center">
  <div class="grid md:grid-cols-3 gap-6 max-w-7xl mx-auto py-12">
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Top Fantasy Players 2025</h3>
      <p class="text-gray-300 mb-2">Discover the must-pick players this season to boost your fantasy points consistently and get ahead of your competition.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Contest Winning Tips</h3>
      <p class="text-gray-300 mb-2">Apply proven strategies to increase your chances of winning high-value contests and climb the leaderboards.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Upcoming Leagues</h3>
      <p class="text-gray-300 mb-2">Prepare your fantasy squads in advance with insights into upcoming leagues, player forms, and match schedules.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Captain Picks Guide</h3>
      <p class="text-gray-300 mb-2">Find out which players are the safest and most effective captain choices to maximize your points in different matchups.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Fantasy Cricket vs Kabaddi</h3>
      <p class="text-gray-300 mb-2">Understand the differences and strategies between cricket and kabaddi fantasy leagues to diversify your gaming skills.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-lg shadow hover:shadow-yellow-500 transition">
      <h3 class="text-xl font-semibold mb-2 text-yellow-400">Live Contest Updates</h3>
      <p class="text-gray-300 mb-2">Stay updated with live contest leaderboards, player performances, and points tracking during matches.</p>
      <a href="#" class="text-yellow-400 hover:underline">Read More</a>
    </div>
  </div>
</main>
<section class="relative flex flex-col items-center justify-center text-center py-22 px-4 bg-cover bg-center">
  <div class="bg-black bg-opacity-7  rounded-2xl w-full max-w-2xl mx-auto animate-fadeInUp shadow-lg">
  <img src="image/1.png" alt="banner" class ="rounded-2xl">
  </div>
</section>

<main class="flex-grow pt-16 px-4 text-center">
  <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-7xl mx-auto py-12">
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Top Fantasy Players 2025</h3>
      <p class="text-gray-300 mb-4">Discover this season’s best picks to boost your fantasy points and gain an edge.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Contest Winning Tips</h3>
      <p class="text-gray-300 mb-4">Apply expert strategies to maximize your chances of winning big contests on Zanthium.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Upcoming Leagues</h3>
      <p class="text-gray-300 mb-4">Prepare your fantasy squads for upcoming leagues with our insider tips and match schedules.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Captain Picks Guide</h3>
      <p class="text-gray-300 mb-4">Find out the best captain choices to maximize your points in upcoming contests.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Fantasy Cricket vs Kabaddi</h3>
      <p class="text-gray-300 mb-4">Understand differences in strategies for cricket and kabaddi to diversify your fantasy gaming skills.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg card-hover">
      <h3 class="text-xl font-bold mb-2 text-yellow-400">Live Contest Updates</h3>
      <p class="text-gray-300 mb-4">Stay updated with live leaderboards, player scores, and match progress to adjust your teams in real-time.</p>
      <a href="#" class="inline-block mt-2 bg-yellow-400 text-black font-semibold px-4 py-2 rounded hover:bg-yellow-500">Read More</a>
    </div>
  </div>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
