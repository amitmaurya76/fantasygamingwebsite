<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FAQs - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/tailwind.min.css" rel="stylesheet" />
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        body {
            background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
        }
        .rounded {
            border-radius: 1.25rem;
        }
        .faq-question {
            cursor: pointer;
        }
    </style>
</head>
<body class="bg-gray-50">
<?php include 'loader.php'; ?>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
            </div>

            <!-- FAQs Card -->
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-6 text-gray-200 text-sm max-h-[70vh] overflow-y-auto">
                <h2 class="text-xl font-bold text-center mb-4">❓ Frequently Asked Questions</h2>

                <div id="faq-container" class="space-y-2">
                    <div class="bg-gray-900 rounded p-3">
                        <h3 class="faq-question font-semibold text-green-400">1️⃣ What is Zanthium?</h3>
                        <p class="faq-answer mt-1 hidden">Zanthium is a fantasy sports platform where users can create teams, join contests, and win real cash while enjoying sports responsibly.</p>
                    </div>
                    <div class="bg-gray-900 rounded p-3">
                        <h3 class="faq-question font-semibold text-green-400">2️⃣ How do I withdraw my winnings?</h3>
                        <p class="faq-answer mt-1 hidden">Go to the Wallet section, click on Withdraw, complete KYC if needed, and enter your bank or UPI details to withdraw your winnings securely.</p>
                    </div>
                    <div class="bg-gray-900 rounded p-3">
                        <h3 class="faq-question font-semibold text-green-400">3️⃣ Is KYC mandatory on Zanthium?</h3>
                        <p class="faq-answer mt-1 hidden">Yes, KYC verification is required for withdrawals to ensure compliance and a safe environment for all users.</p>
                    </div>
                    <div class="bg-gray-900 rounded p-3">
                        <h3 class="faq-question font-semibold text-green-400">4️⃣ How can I contact support?</h3>
                        <p class="faq-answer mt-1 hidden">You can email us at <span class="text-green-400 font-semibold">support@zanthium.com</span> or call us at +91 9876543210 for assistance 24/7.</p>
                    </div>
                    <div class="bg-gray-900 rounded p-3">
                        <h3 class="faq-question font-semibold text-green-400">5️⃣ Is Zanthium legal?</h3>
                        <p class="faq-answer mt-1 hidden">Yes, Zanthium follows the guidelines for skill-based fantasy sports in India and operates in states where fantasy gaming is allowed.</p>
                    </div>
                </div>
            </div>

            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>
    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
    // FAQ toggle
    document.querySelectorAll('.faq-question').forEach(q => {
        q.addEventListener('click', () => {
            const answer = q.nextElementSibling;
            answer.classList.toggle('hidden');
        });
    });
</script>

</body>
</html>
