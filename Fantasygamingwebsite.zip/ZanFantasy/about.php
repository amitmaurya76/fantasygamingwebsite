<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css/tailwind.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
   <link rel="icon" href="image/favicon.ico" type="image/x-icon">

</head>
<body class="bg-gray-50">

<?php include 'loader.php'; ?>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
            </div>

            <!-- About Us Card -->
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-6 text-gray-200 text-sm max-h-[70vh] overflow-y-auto">
                <h2 class="text-xl font-bold text-center mb-2">ℹ️ About Us</h2>
                <p class="text-center text-green-400 font-semibold mb-4">“Where Passion Meets Performance”</p>

                <h3 class="text-green-400 font-semibold mb-1">👥 Who We Are</h3>
                <p class="mb-2">Zanthium is a premium fantasy sports platform dedicated to providing a seamless, fair, and engaging fantasy sports experience to users across India and beyond.</p>

                <h3 class="text-green-400 font-semibold mb-1">🎯 Our Mission</h3>
                <p class="mb-2">Our mission is to build a trusted, transparent, and rewarding ecosystem where sports enthusiasts can showcase their knowledge and skills responsibly while enjoying the thrill of fantasy competition.</p>

                <h3 class="text-green-400 font-semibold mb-1">🚀 Why Zanthium?</h3>
                <ul class="list-disc list-inside mb-2">
                    <li>⚡ Quick withdrawals & secure transactions</li>
                    <li>🏆 Daily exciting contests across sports</li>
                    <li>🔒 Data privacy & fair play guaranteed</li>
                    <li>🤝 24/7 support for your queries</li>
                </ul>

                <p class="mb-2">Join us as we redefine the fantasy sports landscape with technology-driven innovation, ensuring every user enjoys the best possible experience on Zanthium.</p>

                <div class="text-center mt-4">
                    <a href="myleagues.php" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full text-sm shadow transition">🏏 Join Your First League</a>
                </div>
            </div>

            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>

    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
