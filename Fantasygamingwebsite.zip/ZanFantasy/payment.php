<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Payment - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <link href="css\tailwind.min.css" rel="stylesheet"/>
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.2);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
            background: #0f172a;
        }
        #sidebar a:hover {
            background: black;
            font-size: 2rem;
            line-height: 2rem;
            border-radius: 50px;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-800 to-gray-900 min-h-screen">

<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex justify-center items-center p-4">
        <div class="max-w-md w-full bg-gradient-to-r from-gray-800 to-gray-700 rounded-3xl shadow-lg p-6 border border-gray-700">

            <!-- Logo -->
            <div class="flex justify-center mb-4">
                <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12 object-contain" />
            </div>

            <!-- Heading -->
            <h2 class="text-xl font-bold text-center text-white mb-4">💰 Complete Your Payment</h2>

            <!-- Contest Info Card -->
            <div class="bg-gray-900 rounded-lg p-4 mb-4 text-gray-200 space-y-1">
                <div class="flex justify-between">
                    <span>Contest:</span>
                    <span class="font-semibold">Mega League</span>
                </div>
                <div class="flex justify-between">
                    <span>Entry Fee:</span>
                    <span class="font-semibold text-green-400">₹49</span>
                </div>
                <div class="flex justify-between">
                    <span>Potential Winnings:</span>
                    <span class="font-semibold text-green-400">₹5,000</span>
                </div>
                <div class="flex justify-between">
                    <span>Payment Status:</span>
                    <span class="font-semibold text-yellow-400">Pending</span>
                </div>
            </div>

            <!-- Payment Methods -->
            <div class="space-y-2 mb-4">
                <button class="w-full bg-gray-800 hover:bg-gray-700 text-gray-100 py-2 rounded-lg flex items-center justify-center space-x-2">
                    <span>📱</span><span>Pay via UPI</span>
                </button>
                <button class="w-full bg-gray-800 hover:bg-gray-700 text-gray-100 py-2 rounded-lg flex items-center justify-center space-x-2">
                    <span>👛</span><span>Pay with Wallet</span>
                </button>
                <button class="w-full bg-gray-800 hover:bg-gray-700 text-gray-100 py-2 rounded-lg flex items-center justify-center space-x-2">
                    <span>💳</span><span>Credit / Debit Card</span>
                </button>
            </div>

            <!-- Pay Now Button -->
             <a href="coming_soon.php" >
            <button class="w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-semibold transition">Pay ₹49 Now</button>
            </a>
            <p class="text-xs text-gray-400 text-center mt-2">By proceeding, you agree to Zanthium's Terms & Conditions.</p>
        </div>
    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
