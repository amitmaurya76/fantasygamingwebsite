<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>How to Play - Zanthium</title>
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <style>
    .step-card {
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .step-card:hover {
      transform: translateY(-5px) scale(1.02);
      box-shadow: 0 10px 15px rgba(255, 255, 0, 0.3);
    }
  </style>
</head>
<body class="bg-gradient-to-b from-gray-900 to-black text-white min-h-screen flex flex-col">
<?php include 'header.php'; ?>

<section class="relative flex flex-col items-center justify-center text-center py-32 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
  <div class="bg-black bg-opacity-70 p-8 rounded-2xl w-full max-w-2xl mx-auto animate-fadeInUp shadow-lg">
    <h1 class="text-4xl md:text-5xl font-extrabold leading-tight mb-4 text-yellow-400">How to Play on Zanthium</h1>
    <p class="text-lg md:text-xl text-gray-300">Follow these easy steps to start creating your fantasy team and winning real cash on Zanthium.</p>
  </div>
</section>

<main class="flex-grow pt-16 px-4">
  <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-8 max-w-7xl mx-auto py-12">
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/4.png" alt="Sign Up" class="w-48 h-58 mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Sign Up</h3>
      <p class="text-gray-300">Register using your email or mobile number to get started.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/2.png" alt="Select Match" class="w-48 h-58  mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Select a Match</h3>
      <p class="text-gray-300">Choose a match and join a contest you want to play.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/3.png" alt="Create Team" class="w-48 h-58  mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Create Your Team</h3>
      <p class="text-gray-300">Use your sports knowledge to build a winning fantasy team.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/6.png" alt="Track Live Scores" class="w-48 h-58  mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Track Live Scores</h3>
      <p class="text-gray-300">Follow live scores and see your team performance on the leaderboard.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/5.png" alt="Win Cash" class="w-48 h-58  mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Win Cash Rewards</h3>
      <p class="text-gray-300">Win real cash prizes based on your team’s performance.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow-lg step-card flex flex-col items-center text-center">
      <img src="image/7.png" alt="Withdraw Winnings" class="w-48 h-58  mb-4 rounded">
      <h3 class="text-xl font-bold text-yellow-400 mb-2">Withdraw Easily</h3>
      <p class="text-gray-300">Withdraw your winnings securely and quickly into your bank account.</p>
    </div>
  </div>
</main>

<?php include 'footer.php'; ?>

</body>
</html>
