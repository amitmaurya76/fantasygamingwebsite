<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>My Team - Zanthium</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
<link href="css\tailwind.min.css" rel="stylesheet"/>
<link rel="icon" href="image/favicon.ico" type="image/x-icon">
<style>
.gradient-header { background: linear-gradient(90deg, #0f2027, #203a43, #2c5364); }
.player-card { position: absolute; display: flex; flex-direction: column; align-items: center; transition: transform 0.3s ease; }
.player-card img { width: 4rem; height: 4rem; border: 2px solid white; border-radius: 9999px; }
.player-card span { font-size: 0.75rem; }
@media (max-width: 768px) {
.player-card img { width: 2.5rem; height: 2.5rem; }
.player-card span { font-size: 0.65rem; }
}
#sidebar {
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
#sidebar a:hover {
  border-radius: 50px;
  background: black;
  font-size: 2rem;
  line-height: 2rem;
}
body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col lg:flex-row">
<?php include 'loader.php'; ?>

<!-- Sidebar -->
  <?php include 'sidebar.php'; ?>


<!-- Main Content -->
<div class="flex-1 flex flex-col lg:flex-row h-screen overflow-hidden justify-center">
<div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >

    <!-- Logo -->
    <div class="w-full h-12 mb-4 flex items-center justify-center">
      <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
    </div>


    <!-- Header -->
    <div class="bg-gray-800 text-center rounded-lg p-2 font-semibold text-white text-sm mb-4">
      My Team Preview (Pitch View)
    </div>

    <!-- Pitch Area -->
<div class="relative rounded-xl mx-auto w-full bg-center bg-cover p-4 mb-4" style="background-image: url('image/grand-stadium-full-spectators-expecting-600nw-1807322755.webp'); min-height: 550px;">

  <!-- Wicket Keepers -->
  <h2 class="text-center text-sm text-white font-semibold mb-1">Wicket Keepers</h2>
  <div class="flex justify-center space-x-4 mb-3">
    <div class="flex flex-col items-center">
      <img src="image/player9.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">WK</span>
      <span class="text-xs text-gray-300">9.5</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player1.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">WK</span>
      <span class="text-xs text-gray-300">11.0</span>
    </div>
  </div>

  <!-- Batsmen -->
  <h2 class="text-center text-sm text-white font-semibold mb-1">Batsmen</h2>
  <div class="flex justify-center flex-wrap gap-4 mb-3">
    <div class="flex flex-col items-center">
      <img src="image/player2.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BAT</span>
      <span class="text-xs text-gray-300">11.0</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player3.png" class="w-16 h-16 rounded border-4 border-yellow-400">
      <span class="text-xs text-white">BAT (C)</span>
      <span class="text-xs text-gray-300">12.5</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player4.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BAT</span>
      <span class="text-xs text-gray-300">9.5</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player5.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BAT</span>
      <span class="text-xs text-gray-300">8.5</span>
    </div>
  </div>

  <!-- All-Rounders -->
  <h2 class="text-center text-sm text-white font-semibold mb-1">All-Rounders</h2>
  <div class="flex justify-center space-x-4 mb-3">
    <div class="flex flex-col items-center">
      <img src="image/player6.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">AR</span>
      <span class="text-xs text-gray-300">10.0</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player7.png" class="w-16 h-16 rounded border-4 border-green-400">
      <span class="text-xs text-white">AR (VC)</span>
      <span class="text-xs text-gray-300">9.0</span>
    </div>
  </div>

  <!-- Bowlers -->
  <h2 class="text-center text-sm text-white font-semibold mb-1">Bowlers</h2>
  <div class="flex justify-center flex-wrap gap-4">
    <div class="flex flex-col items-center">
      <img src="image/player8.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BOWL</span>
      <span class="text-xs text-gray-300">8.0</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player11.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BOWL</span>
      <span class="text-xs text-gray-300">9.5</span>
    </div>
    <div class="flex flex-col items-center">
      <img src="image/player10.png" class="w-16 h-16 rounded border-2 border-white">
      <span class="text-xs text-white">BOWL</span>
      <span class="text-xs text-gray-300">8.0</span>
    </div>
  </div>

</div>


    <!-- Enter Contest Button -->
    <a href="coming_soon2.php">
    <button class="w-full py-3 bg-green-600 hover:bg-green-700 rounded-lg font-bold">
      Enter Contest →
    </button>
</a>
  </div>

  <!-- Right Download Section (Desktop) -->
      <?php include 'DownloadSection.php'; ?>

</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
