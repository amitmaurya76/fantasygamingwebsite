<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Contests - Zanthium</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" /> 
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
  <link href="css\tailwind.min.css" rel="stylesheet"/>

  <style>
    #sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
  </style>
</head>
<body class="bg-gray-50">
<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">

  <!-- Sidebar -->
      <?php include 'sidebar.php'; ?>


  <!-- Main Content -->
  <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
    <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >

      
      <!-- Logo -->
      <div class="w-full h-12 mb-4 flex items-center">
        <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
      </div>

      <!-- Sports Tabs -->
      <div class="flex justify-between mb-4">
        <button class="tab-btn flex-1 py-2 text-center bg-green-600 text-white rounded-l" data-tab="cricket">Cricket</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white" data-tab="football">Football</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white" data-tab="basketball">Basketball</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white rounded-r" data-tab="kabaddi">Kabaddi</button>
      </div>

      <!-- Match Header -->
      <div class="bg-gradient-to-r from-gray-900 to-gray-700 p-4 rounded-lg text-white flex justify-between items-center mb-4">
        <div class="flex items-center space-x-4">
          <div class="flex flex-col items-center">
            <img src="image/team1.png" alt="WLS" class="w-12 h-12 rounded-full border border-white">
            <span class="text-xs">Team 1</span>
          </div>
          <span>vs</span>
          <div class="flex flex-col items-center">
            <img src="image/team2.png" alt="CBR" class="w-12 h-12 rounded-full border border-white">
            <span class="text-xs">Team 2</span>
          </div>
        </div>
        <div class="text-center">
          <span class="block text-xs text-gray-300">Time Left</span>
          <span id="countdown" class="text-green-400 font-bold">0h 9m</span>
        </div>
      </div>

      <!-- Contests Section -->
      <div id="contests" class="space-y-4 overflow-y-auto max-h-[70vh] pr-1">
        
        <!-- Contest Card -->
        <div class="bg-white rounded-lg shadow p-4" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
          <div class="flex justify-between items-center mb-2">
            <div>
              <p class="text-xs text-gray-300">PRIZE POOL</p>
              <p class="text-xl font-bold text-white">₹35,000,000</p>
              <p class="text-xs text-gray-300">60% Winners | 1st ₹2,00,00,000</p>
            </div>
            <div class="text-right">
              <p class="bg-green-600 text-white px-3 py-1 rounded-full text-sm">₹49</p>
              <p class="text-xs text-gray-300 mt-1">Multiple Entries</p>
            </div>
          </div>
          <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="bg-green-500 h-2 rounded-full" style="width: 62%"></div>
          </div>
          <p class="text-xs text-green-400 text-right">3,875 spots left</p>
          <a href="contestdetails.php?contest_id=1" class="block text-center bg-green-500 hover:bg-green-600 text-white rounded py-2 text-sm font-semibold mt-2">Join Contest</a>
        </div>

        <!-- Contest Card -->
        <div class="bg-white rounded-lg shadow p-4" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
          <div class="flex justify-between items-center mb-2">
            <div>
              <p class="text-xs text-gray-300">PRIZE POOL</p>
              <p class="text-xl font-bold text-white">₹1,000,000</p>
              <p class="text-xs text-gray-300">50% Winners | 1st ₹10,000</p>
            </div>
            <div class="text-right">
              <p class="bg-green-600 text-white px-3 py-1 rounded-full text-sm">₹15</p>
              <p class="text-xs text-gray-300 mt-1">Multiple Entries</p>
            </div>
          </div>
          <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="bg-green-500 h-2 rounded-full" style="width: 81%"></div>
          </div>
          <p class="text-xs text-green-400 text-right">5,670 spots left</p>
          <a href="contestdetails.php?contest_id=2" class="block text-center bg-green-500 hover:bg-green-600 text-white rounded py-2 text-sm font-semibold mt-2">Join Contest</a>
        </div>
        <div class="bg-white rounded-lg shadow p-4" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
          <div class="flex justify-between items-center mb-2">
            <div>
              <p class="text-xs text-gray-300">PRIZE POOL</p>
              <p class="text-xl font-bold text-white">₹110,000,000</p>
              <p class="text-xs text-gray-300">50% Winners | 1st ₹1000,000</p>
            </div>
            <div class="text-right">
              <p class="bg-green-600 text-white px-3 py-1 rounded-full text-sm">₹115</p>
              <p class="text-xs text-gray-300 mt-1">Multiple Entries</p>
            </div>
          </div>
          <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="bg-green-500 h-2 rounded-full" style="width: 81%"></div>
          </div>
          <p class="text-xs text-green-400 text-right">4,670 spots left</p>
          <a href="contestdetails.php?contest_id=2" class="block text-center bg-green-500 hover:bg-green-600 text-white rounded py-2 text-sm font-semibold mt-2">Join Contest</a>
        </div>
        <div class="bg-white rounded-lg shadow p-4" style="background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);">
          <div class="flex justify-between items-center mb-2">
            <div>
              <p class="text-xs text-gray-300">PRIZE POOL</p>
              <p class="text-xl font-bold text-white">₹3,000,000</p>
              <p class="text-xs text-gray-300">50% Winners | 1st ₹1000,000</p>
            </div>
            <div class="text-right">
              <p class="bg-green-600 text-white px-3 py-1 rounded-full text-sm">₹55</p>
              <p class="text-xs text-gray-300 mt-1">Multiple Entries</p>
            </div>
          </div>
          <div class="w-full bg-gray-700 rounded-full h-2">
            <div class="bg-green-500 h-2 rounded-full" style="width: 81%"></div>
          </div>
          <p class="text-xs text-green-400 text-right">55,670 spots left</p>
          <a href="contestdetails.php?contest_id=2" class="block text-center bg-green-500 hover:bg-green-600 text-white rounded py-2 text-sm font-semibold mt-2">Join Contest</a>
        </div>

      </div>
    </div>

    <!-- Right Download Section (Desktop) -->
        <?php include 'DownloadSection.php'; ?>

  </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
// Countdown Timer
let countdownSeconds = 9 * 60;
const countdownEl = document.getElementById('countdown');
const interval = setInterval(() => {
  if (countdownSeconds <= 0) {
    clearInterval(interval);
    countdownEl.textContent = 'Started';
    return;
  }
  const m = Math.floor(countdownSeconds / 60);
  const s = countdownSeconds % 60;
  countdownEl.textContent = `${m}m ${s}s`;
  countdownSeconds--;
}, 1000);
</script>

</body>
</html>
