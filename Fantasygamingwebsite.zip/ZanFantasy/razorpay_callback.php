<?php
session_start();
include 'db.php';

use Razorpay\Api\Api;

$api = new Api('rzp_test_yourkey', 'your_secret');

$payment_id = $_GET['payment_id'];
$order_id = $_GET['order_id'];
$user_id = $_SESSION['user_id'];
$entry_fee = $_SESSION['entry_fee'] ?? 49;

try {
    $payment = $api->payment->fetch($payment_id);
    if ($payment->status == 'captured') {
        // Log successful transaction
        $pdo->prepare("INSERT INTO transactions (user_id, amount, mode, status, created_at) VALUES (?, ?, ?, ?, NOW())")
            ->execute([$user_id, $entry_fee, 'Razorpay', 'Success']);

        header("Location: payment_success.php?amount=$entry_fee&mode=Razorpay");
        exit();
    } else {
        throw new Exception("Payment not captured.");
    }
} catch (Exception $e) {
    $pdo->prepare("INSERT INTO transactions (user_id, amount, mode, status, created_at) VALUES (?, ?, ?, ?, NOW())")
        ->execute([$user_id, $entry_fee, 'Razorpay', 'Failed']);

    header("Location: payment_failed.php?reason=" . urlencode($e->getMessage()));
    exit();
}
?>
