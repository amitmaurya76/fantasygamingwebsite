<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Zanthium</title>
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-900 text-white min-h-screen flex flex-col">
  <?php include 'header.php'; ?>

    <section class="relative flex flex-col items-center justify-center text-center py-32 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
    <div class="bg-black bg-opacity-70 p-8 rounded-xl w-full mx-auto">
            <h1 class="text-4xl md:text-6xl font-extrabold leading-tight"><span class="text-yellow-400">About</span></h1>
            <p class="mt-4 text-lg md:text-xl">Create your team, join contests, and win real cash while enjoying your favourite sports leagues.</p>
    </div>
    </section>

  <main class="flex-grow flex items-center justify-center pt-24 px-4">
    <div class="max-w-2xl text-center">
      <h1 class="text-4xl md:text-5xl font-bold mb-6">About Zanthium</h1>
      <p class="mb-4 text-gray-300">Zanthium is India’s fast-growing fantasy sports platform, offering an immersive and seamless experience for sports lovers to build their dream teams and participate in real-time contests.</p>
      <p class="mb-4 text-gray-300">Founded in 2022, Zanthium's mission is to make fantasy sports accessible, rewarding, and engaging by providing an intuitive interface and rewarding gameplay across cricket, football, and kabaddi.</p>
      <p class="mb-4 text-gray-300">Our vision is to build a thriving fantasy sports community where players can showcase their sports knowledge, compete, and win rewards while enjoying the thrill of live matches.</p>
      <p class="mb-4 text-gray-300">With secure payment systems, live leaderboards, and transparent contest structures, Zanthium ensures fair play and a premium gaming experience for all users.</p>
    </div>
  </main>
   <section class="relative flex flex-col items-center justify-center text-center py-40 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
    <div class="bg-black bg-opacity-70 p-10 rounded-2xl w-full max-w-3xl mx-auto animate-fadeInUp">
      <h1 class="text-4xl md:text-6xl font-extrabold leading-tight mb-4"><span class="text-yellow-400">About Zanthium</span></h1>
      <p class="text-lg md:text-xl text-gray-300">Building a thriving fantasy sports community to showcase your sports knowledge, compete, and win while enjoying live matches.</p>
    </div>
  </section>

  <main class="flex-grow flex flex-col items-center justify-center px-4 py-20">
    <div class="max-w-4xl text-center space-y-6">
      <h2 class="text-3xl md:text-4xl font-bold text-yellow-400">Who We Are</h2>
      <p class="text-gray-300">Founded in 2022, Zanthium is India’s fast-growing fantasy sports platform, offering immersive and seamless experiences for sports lovers to build their dream teams, join contests, and win real rewards.</p>
      <h2 class="text-3xl md:text-4xl font-bold text-yellow-400">Our Mission</h2>
      <p class="text-gray-300">Our mission is to make fantasy sports accessible, rewarding, and engaging, providing intuitive interfaces and fair gameplay across cricket, football, and kabaddi with secure payment systems and transparent contests.</p>
      <h2 class="text-3xl md:text-4xl font-bold text-yellow-400">What Makes Us Unique</h2>
      <p class="text-gray-300">With live leaderboards, detailed player statistics, daily challenges, and a supportive community, Zanthium ensures you enjoy the thrill of live matches while showcasing your sports strategies to earn rewards.</p>
      <h2 class="text-3xl md:text-4xl font-bold text-yellow-400">Join Us Today</h2>
      <p class="text-gray-300">Experience premium fantasy sports, engage in exclusive contests, and join a community of sports enthusiasts. Whether you are a cricket, football, or kabaddi fan, Zanthium is your platform to play and win daily.</p>
      <a href="play-game.php" class="mt-8 inline-block bg-yellow-400 hover:bg-yellow-500 text-black font-semibold px-8 py-3 rounded-lg transition">Start Playing Now</a>
    </div>
  </main>


  <?php include 'footer.php'; ?>

</body>
</html>
