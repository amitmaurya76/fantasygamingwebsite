<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Careers - Zanthium</title>
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-b from-gray-900 to-black text-white min-h-screen flex flex-col">
<?php include 'header.php'; ?>

<section class="relative flex flex-col items-center justify-center text-center py-32 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
  <div class="bg-black bg-opacity-70 p-8 rounded-2xl w-full max-w-2xl mx-auto animate-fadeInUp shadow-lg">
    <h1 class="text-4xl md:text-5xl font-extrabold leading-tight mb-4 text-yellow-400">Careers at Zanthium</h1>
    <p class="text-lg md:text-xl text-gray-300">Join our passionate team shaping the future of fantasy sports in India and globally.</p>
  </div>
</section>

<main class="flex-grow pt-16 px-4 text-center">
  <div class="max-w-3xl mx-auto space-y-6">
    <p class="text-gray-300">We are looking for talented developers, designers, marketers, and sports analysts to join us in building an engaging and rewarding platform for fantasy sports enthusiasts.</p>
    <p class="text-gray-300">At Zanthium, you will work with a collaborative team, innovate in the fantasy sports industry, and grow your skills while making a direct impact on millions of users.</p>
    <p class="text-gray-300">We offer a flexible, remote-friendly environment with opportunities to lead projects, experiment with new technologies, and contribute your creative ideas to shape the Zanthium experience.</p>
    <p class="text-gray-300">If you are passionate about sports, technology, and building communities, we would love to hear from you!</p>
    <a href="mailto:careers@Zanthium.com" class="mt-8 inline-block bg-yellow-400 hover:bg-yellow-500 text-black font-semibold px-8 py-3 rounded-lg transition">Apply Now</a>
  </div>

  <div class="max-w-5xl mx-auto grid sm:grid-cols-2 md:grid-cols-3 gap-6 mt-12 mb-12 px-4">
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon5.png" alt="Developer Role" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Developers</h3>
      <p class="text-gray-300 text-sm">Join our engineering team to build scalable, user-friendly fantasy sports systems.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon2.png" alt="Designer Role" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Designers</h3>
      <p class="text-gray-300 text-sm">Craft beautiful, intuitive interfaces for our apps and websites, enhancing user experience.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon3.png" alt="Marketing Role" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Marketers</h3>
      <p class="text-gray-300 text-sm">Help us reach and engage millions of fantasy sports fans across India and globally.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon1.png" alt="Sports Analyst Role" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Sports Analysts</h3>
      <p class="text-gray-300 text-sm">Analyze matches, players, and data to provide insights that enrich user gameplay.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon6.png" alt="Support Role" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Support Executives</h3>
      <p class="text-gray-300 text-sm">Assist our users and ensure a seamless experience across the platform.</p>
    </div>
    <div class="bg-gray-800 p-6 rounded-xl shadow hover:shadow-yellow-500 transition flex flex-col items-center">
      <img src="image/icon4.png" alt="Internships" class="w-20 h-20 mb-4 rounded-full">
      <h3 class="text-lg font-semibold text-yellow-400 mb-2">Internships</h3>
      <p class="text-gray-300 text-sm">Kickstart your career by learning and contributing to real projects at Zanthium.</p>
    </div>
  </div>
</main>

<?php include 'footer.php'; ?>

</body>
</html>