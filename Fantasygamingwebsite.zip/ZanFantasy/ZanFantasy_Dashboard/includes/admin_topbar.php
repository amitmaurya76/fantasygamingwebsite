<!-- includes/admin_topbar.php -->
<header class="bg-gradient-to-r from-gray-900 to-gray-700 flex items-center justify-between bg-gray-900 text-white p-4 md:ml-64">
    <button id="menuButton" class="md:hidden text-green-400 text-2xl focus:outline-none">☰</button>
    <div class="text-lg font-bold text-green-400">Admin Panel</div>
    <div class="flex items-center space-x-3">
        <span class="text-sm">Hi, Amit</span>
    <a href="admin_profile.php">
        <img src="image/user/admin_avatar.png" alt="Admin" class="h-8 w-8 rounded-full border-2 border-purple-500 ">
        </a>
    </div>
</header>

<script>
    const menuButton = document.getElementById('menuButton');
    const sidebar = document.getElementById('sidebar');
    menuButton.addEventListener('click', () => {
        sidebar.classList.toggle('-translate-x-full');
    });
</script>
