<!-- includes/admin_sidebar.php -->
<!-- Latest Font Awesome CDN -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<aside id="sidebar" class=" bg-gradient-to-r from-gray-900 to-gray-700 fixed inset-y-0 left-0 w-64 rounded-r-lg text-white p-4 transform -translate-x-full md:translate-x-0 transition-transform duration-300 z-50">
    <div class="text-2xl font-bold text-green-400 mb-6">
        <a href="index.php">
            <img src="image/logo-white.png" alt="logo">
        </a>
    </div>
    <nav class="space-y-2">
        <a href="admin_dashboard.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-house-user"></i> Dashboard</a>
        <a href="admin_users.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-users"></i> Users</a>
        <a href="admin_leagues.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-baseball-bat-ball"></i> Leagues</a>
        <a href="admin_payments.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-credit-card"></i> Payments</a>
        <a href="admin_games.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-puzzle-piece"></i> Game Management</a>
        <a href="admin_leaderboard.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-trophy"></i> Leaderboard</a>
        <a href="admin_settings.php" class="block py-2 px-3 rounded hover:bg-green-600 transition"><i class="fa-solid fa-gear"></i> Settings</a>
        <a href="admin_logout.php" class="block py-2 px-3 rounded hover:bg-red-500 transition"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
    </nav>
    <!-- Download App Section -->
<div class="bg-gradient-to-r from-green-500 to-green-600 mt-2 mb-5 rounded-xl p-3 flex flex-col items-center text-white text-center">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mb-2 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
    </svg>
    <p class="text-sm font-semibold">Download Zanthium App</p>
    <a href="your-app-download-link.apk" download class="mt-2 bg-white text-green-600 hover:bg-gray-100 transition px-4 py-1 rounded-full text-xs font-semibold">
       <i class="fa-solid fa-cloud-arrow-down"></i> Download Now
    </a>
</div>

</aside>
