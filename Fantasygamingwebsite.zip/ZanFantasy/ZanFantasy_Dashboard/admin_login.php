<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <!-- Your Custom Styles
    <link href="css/style.css" rel="stylesheet" />
    <link href="css/tailwind.min.css" rel="stylesheet"/> -->

    <!-- Favicon -->
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <style>
        body {
            background: linear-gradient(135deg, #1d3138, #2c5364, #000000);
        }
        .login-card {
            background: linear-gradient(135deg, #1d3138, #2c5364, #000000);
            border-radius: 1rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            border:1px solid rgb(64, 98, 112);
        }
        .login-input {
            background: #2c5364;
            border: 1px solid #d1d5db;
            transition: all 0.3s ease;
        }
        .login-input:focus {
            border-color: #22c55e;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.3);
        }
        .login-button {
            background: linear-gradient(to right, #22c55e, #16a34a);
            transition: all 0.3s ease;
        }
        .login-button:hover {
            background: linear-gradient(to right, #16a34a, #15803d);
            transform: translateY(-1px);
        }
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.6s ease-out;
        }
    </style>
</head>

<body class="flex items-center justify-center min-h-screen relative">

<!-- Loader -->
<?php include 'loader.php'; ?>

<!-- Login Card -->
<div class="login-card p-6 w-full max-w-sm mx-4 animate-fade-in">
    <!-- Logo -->
    <div class="flex justify-center mb-4">
        <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12">
    </div>

    <!-- Heading -->
    <h2 class="text-center text-2xl font-bold text-gray-50 mb-1">Welcome Back 👋</h2>
    <p class="text-center text-sm text-gray-50 mb-4">Login to continue to Zanthium</p>

    <!-- Form -->
    <form action="admin_dashboard.php" method="POST" class="space-y-4">
        <div>
            <label for="email" class="text-xs text-gray-600">Email or Mobile</label>
            <input 
                type="text" 
                id="email" 
                name="email" 
                required 
                class="login-input w-full mt-1 px-3 py-2 rounded focus:outline-none" 
                placeholder="you@example.com or +919876543210"
            >
        </div>
        <div>
            <label for="password" class="text-xs text-gray-600">Password</label>
            <input 
                type="password" 
                id="password" 
                name="password" 
                required 
                class="login-input w-full mt-1 px-3 py-2 rounded focus:outline-none" 
                placeholder="••••••••"
            >
        </div>
        <button  class="login-button w-full text-white font-semibold py-2 rounded shadow">
            🔐 Login
        </button>
    </form>

    <!-- Links -->
    <div class="flex justify-between text-xs text-gray-500 mt-4">
        <a href="forgot_password.php" class="hover:text-green-500 transition">Forgot Password?</a>
        <a href="register.php" class="hover:text-green-500 transition">Create Account</a>
    </div>
</div>



</body>
</html>
