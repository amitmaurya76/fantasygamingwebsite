<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Admin - Leaderboard | Zanthium</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
<link rel="icon" href="image/favicon.ico" type="image/x-icon">
<style>
.fade-in { animation: fadeIn 0.5s ease-in-out; }
@keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
.glass-card {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255,255,255,0.1);
    transition: all 0.3s ease;
}
.glass-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 15px 25px rgba(0,0,0,0.2);
}
</style>
</head>

<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 fade-in space-y-6">

<!-- Header -->
<div class="flex flex-col md:flex-row md:justify-between md:items-center">
    <h1 class="text-2xl font-bold text-green-400 mb-2"><i class="fa-solid fa-trophy mr-1"></i> Leaderboard</h1>
    <div class="flex space-x-2">
        <input type="text" placeholder="🔍 Search match..." class="px-3 py-2 rounded bg-gray-800 border border-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
        <select class="px-3 py-2 rounded bg-gray-800 border border-gray-700 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
            <option>All Sports</option>
            <option>Football</option>
            <option>Cricket</option>
            <option>Kabaddi</option>
            <option>Basketball</option>
        </select>
    </div>
</div>

<!-- Live Matches Cards -->
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

    <!-- Card 1 -->
    <div class="glass-card rounded-xl p-4 space-y-3">
        <div class="flex justify-between items-center">
            <span class="text-sm text-gray-300"><i class="fa-solid fa-futbol mr-1"></i> Group A | 850K Players</span>
            <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
        <div class="flex justify-between items-center">
            <div class="text-center">
                <img src="https://flagcdn.com/w20/es.png" alt="Spain" class="inline-block mb-1">
                <p class="text-sm">Spain</p>
            </div>
            <div class="text-center text-2xl font-bold">2 - 1</div>
            <div class="text-center">
                <img src="https://flagcdn.com/w20/fr.png" alt="France" class="inline-block mb-1">
                <p class="text-sm">France</p>
            </div>
        </div>
        <div class="flex justify-between text-xs text-gray-300">
            <p>65% Spain</p>
            <p>35% France</p>
        </div>
        <div class="text-xs text-gray-400">12M Players already bid</div>
        <div class="flex space-x-2">
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
            <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
        </div>
    </div>

    <!-- Card 2 -->
    <div class="glass-card rounded-xl p-4 space-y-3">
        <div class="flex justify-between items-center">
            <span class="text-sm text-gray-300"><i class="fa-solid fa-cricket mr-1"></i> Group B | 1.2M Players</span>
            <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
        <div class="flex justify-between items-center">
            <div class="text-center">
                <img src="https://flagcdn.com/w20/au.png" alt="Australia" class="inline-block mb-1">
                <p class="text-sm">Australia</p>
            </div>
            <div class="text-center text-2xl font-bold">4 - 3</div>
            <div class="text-center">
                <img src="https://flagcdn.com/w20/in.png" alt="India" class="inline-block mb-1">
                <p class="text-sm">India</p>
            </div>
        </div>
        <div class="flex justify-between text-xs text-gray-300">
            <p>58% Australia</p>
            <p>42% India</p>
        </div>
        <div class="text-xs text-gray-400">17M Players already bid</div>
        <div class="flex space-x-2">
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
            <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
        </div>
    </div>

    <!-- Card 3 -->
    <div class="glass-card rounded-xl p-4 space-y-3">
        <div class="flex justify-between items-center">
            <span class="text-sm text-gray-300"></i> Group C | 500K Players</span>
            <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
        </div>
        <div class="flex justify-between items-center">
            <div class="text-center">
                <img
  src="https://flagcdn.com/w20/pk.png"
  srcset="https://flagcdn.com/w40/pk.png 2x"
  width="20"
  alt="South Africa">
                <p class="text-sm">Pakistan</p>
            </div>
            <div class="text-center text-2xl font-bold">88 - 92</div>
            <div class="text-center">
                <img
  src="https://flagcdn.com/w20/za.png"
  srcset="https://flagcdn.com/w40/za.png 2x"
  width="20"
  alt="South Africa">
                <p class="text-sm">South Africa</p>
            </div>
        </div>
        <div class="flex justify-between text-xs text-gray-300">
            <p>47% Pakistan</p>
            <p>53% South Africa</p>
        </div>
        <div class="text-xs text-gray-400">5M Players already bid</div>
        <div class="flex space-x-2">
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
            <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
            <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
        </div>
    </div>
    <!-- Card 4 -->
<div class="glass-card rounded-xl p-4 space-y-3">
    <div class="flex justify-between items-center">
        <span class="text-sm text-gray-300"><i class="fa-solid fa-basketball mr-1"></i> Group D | 650K Players</span>
        <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
    </div>
    <div class="flex justify-between items-center">
        <div class="text-center">
            <img src="https://flagcdn.com/w20/us.png" alt="USA" class="inline-block mb-1">
            <p class="text-sm">USA</p>
        </div>
        <div class="text-center text-2xl font-bold">98 - 95</div>
        <div class="text-center">
            <img src="https://flagcdn.com/w20/ca.png" alt="Canada" class="inline-block mb-1">
            <p class="text-sm">Canada</p>
        </div>
    </div>
    <div class="flex justify-between text-xs text-gray-300">
        <p>51% USA</p>
        <p>49% Canada</p>
    </div>
    <div class="text-xs text-gray-400">9M Players already bid</div>
    <div class="flex space-x-2">
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
        <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
    </div>
</div>

<!-- Card 5 -->
<div class="glass-card rounded-xl p-4 space-y-3">
    <div class="flex justify-between items-center">
        <span class="text-sm text-gray-300"><i class="fa-solid fa-hockey-puck mr-1"></i> Group E | 400K Players</span>
        <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
    </div>
    <div class="flex justify-between items-center">
        <div class="text-center">
            <img src="https://flagcdn.com/w20/ru.png" alt="Russia" class="inline-block mb-1">
            <p class="text-sm">Russia</p>
        </div>
        <div class="text-center text-2xl font-bold">3 - 2</div>
        <div class="text-center">
            <img src="https://flagcdn.com/w20/se.png" alt="Sweden" class="inline-block mb-1">
            <p class="text-sm">Sweden</p>
        </div>
    </div>
    <div class="flex justify-between text-xs text-gray-300">
        <p>54% Russia</p>
        <p>46% Sweden</p>
    </div>
    <div class="text-xs text-gray-400">3.5M Players already bid</div>
    <div class="flex space-x-2">
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
        <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
    </div>
</div>

<!-- Card 6 -->
<div class="glass-card rounded-xl p-4 space-y-3">
    <div class="flex justify-between items-center">
        <span class="text-sm text-gray-300"><i class="fa-solid fa-volleyball mr-1"></i> Group F | 300K Players</span>
        <button class="text-gray-400 hover:text-white"><i class="fa-solid fa-ellipsis-vertical"></i></button>
    </div>
    <div class="flex justify-between items-center">
        <div class="text-center">
            <img src="https://flagcdn.com/w20/br.png" alt="Brazil" class="inline-block mb-1">
            <p class="text-sm">Brazil</p>
        </div>
        <div class="text-center text-2xl font-bold">25 - 22</div>
        <div class="text-center">
            <img src="https://flagcdn.com/w20/ar.png" alt="Argentina" class="inline-block mb-1">
            <p class="text-sm">Argentina</p>
        </div>
    </div>
    <div class="flex justify-between text-xs text-gray-300">
        <p>60% Brazil</p>
        <p>40% Argentina</p>
    </div>
    <div class="text-xs text-gray-400">2.1M Players already bid</div>
    <div class="flex space-x-2">
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
        <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
        <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
    </div>
</div>

</div>

<!-- Leaderboard Table -->
<div class="glass-card rounded-xl p-4 mt-6 overflow-x-auto">
    <div class="flex justify-between mb-3">
        <h2 class="text-green-400 font-semibold"><i class="fa-solid fa-ranking-star mr-1"></i> Global Leaderboard</h2>
        <div class="flex space-x-2">
            <button class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-xs"><i class="fa-solid fa-trash mr-1"></i> Delete</button>
            <button class="bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded text-xs"><i class="fa-solid fa-sort mr-1"></i> Sort</button>
            <button class="bg-gray-700 hover:bg-gray-600 px-3 py-1 rounded text-xs"><i class="fa-solid fa-pen mr-1"></i> Edit</button>
        </div>
    </div>
    <table class="min-w-full text-left text-sm">
        <thead class="text-gray-400 border-b border-gray-700">
            <tr>
                <th class="px-4 py-2">Rank</th>
                <th class="px-4 py-2">Player</th>
                <th class="px-4 py-2">Game</th>
                <th class="px-4 py-2">Score</th>
                <th class="px-4 py-2">Earnings</th>
                <th class="px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
            <?php
            $players = [
                [1, "Amit Maurya", "Football", 1350, "₹12,500"],
                [2, "Priya Verma", "Cricket", 1280, "₹11,200"],
                [3, "Ayush Singh", "Basketball", 1190, "₹10,800"],
                [4, "Anjali Yadav", "Kabaddi", 1130, "₹9,750"],
                [5, "Raj Patel", "Hockey", 1085, "₹9,200"],
                [6, "Sneha Sharma", "Badminton", 1045, "₹8,900"],
                [7, "Ravi Kumar", "Football", 1020, "₹8,450"],
                [8, "Manish Tiwari", "Cricket", 980, "₹8,000"],
                [9, "Pooja Gupta", "Basketball", 940, "₹7,750"],
                [10, "Kunal Mehta", "Football", 915, "₹7,500"],
                [11, "Divya Soni", "Kabaddi", 890, "₹7,200"],
                [12, "Vikas Jha", "Cricket", 870, "₹7,000"],
                [13, "Rohit Raj", "Hockey", 850, "₹6,750"],
                [14, "Neha Mishra", "Badminton", 830, "₹6,500"],
                [15, "Alok Sharma", "Football", 810, "₹6,300"],
            ];
            foreach ($players as $p) {
                echo "
                <tr class='hover:bg-gray-800 transition'>
                    <td class='px-4 py-2'>{$p[0]}</td>
                    <td class='px-4 py-2'>{$p[1]}</td>
                    <td class='px-4 py-2'>{$p[2]}</td>
                    <td class='px-4 py-2'>{$p[3]}</td>
                    <td class='px-4 py-2'>{$p[4]}</td>
                    <td class='px-4 py-2 space-x-1'>
                        <button class='text-blue-400 hover:text-blue-600'><i class='fa-solid fa-eye'></i></button>
                        <button class='text-yellow-400 hover:text-yellow-600'><i class='fa-solid fa-pen'></i></button>
                        <button class='text-red-400 hover:text-red-600'><i class='fa-solid fa-trash'></i></button>
                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>


</main>
</body>
</html>
