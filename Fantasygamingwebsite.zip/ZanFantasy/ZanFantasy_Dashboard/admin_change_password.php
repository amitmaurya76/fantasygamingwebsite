<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Change Password | Admin - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        .glow-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 20px rgba(34, 197, 94, 0.25);
            transition: all 0.3s ease;
        }
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from { opacity:0; transform: translateY(10px); } to { opacity:1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">
<?php include 'loader.php'; ?>

<main class="p-4 md:ml-64 fade-in max-w-xl mx-auto space-y-6">
    <h1 class="text-2xl font-bold text-green-400 text-center mb-4">🔐 Change Password</h1>

    <div class="bg-gray-800 rounded-xl p-6 shadow-lg glow-card">
        <form action="404.php" method="POST" class="space-y-4">
            <div>
                <label class="block text-sm text-gray-300 mb-1">Current Password</label>
                <input type="password" name="current_password" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400 focus:ring-1 focus:ring-green-400 text-white" required>
            </div>
            <div>
                <label class="block text-sm text-gray-300 mb-1">New Password</label>
                <input type="password" name="new_password" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400 focus:ring-1 focus:ring-green-400 text-white" required>
            </div>
            <div>
                <label class="block text-sm text-gray-300 mb-1">Confirm New Password</label>
                <input type="password" name="confirm_password" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400 focus:ring-1 focus:ring-green-400 text-white" required>
            </div>
            <button type="submit" class="w-full bg-green-500 hover:bg-green-600 transition text-white font-semibold py-2 rounded">Update Password</button>
        </form>
    </div>
</main>

</body>
</html>
