<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin - Settings | Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <script src="https://unpkg.com/feather-icons"></script>
    <style>
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 25px rgba(34, 197, 94, 0.15),
                        0 0 20px rgba(34, 197, 94, 0.3);
        }
        input, select { color-scheme: dark; }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<!-- Toast Notification -->
<div id="toast" class="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded hidden z-50"></div>

<main class="p-4 md:ml-64 fade-in space-y-6">
    <h1 class="text-2xl font-bold text-green-400 mb-4 flex items-center space-x-2"><i data-feather="settings"></i><span>Settings & KYC Controls</span></h1>

    <!-- KYC and Payout Settings Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="glass-card rounded-lg p-6 space-y-3">
            <h2 class="text-green-400 font-semibold flex items-center space-x-2"><i data-feather="dollar-sign"></i><span>Minimum Withdrawal</span></h2>
            <input type="number" value="100" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
            <button onclick="showToast('✅ Minimum withdrawal updated')" class="w-full bg-green-500 hover:bg-green-600 transition text-white font-semibold py-2 rounded">Save</button>
        </div>

        <div class="glass-card rounded-lg p-6 space-y-3">
            <h2 class="text-yellow-400 font-semibold flex items-center space-x-2"><i data-feather="shield"></i><span>KYC Verification Required</span></h2>
            <label class="flex items-center cursor-pointer">
                <div class="relative">
                    <input type="checkbox" checked class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:bg-yellow-500 transition-all"></div>
                    <div class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition peer-checked:translate-x-full"></div>
                </div>
                <span class="ml-3 text-sm">Require KYC</span>
            </label>
            <button onclick="showToast('✅ KYC requirement updated')" class="w-full bg-yellow-500 hover:bg-yellow-600 transition text-white font-semibold py-2 rounded">Update</button>
        </div>

        <div class="glass-card rounded-lg p-6 space-y-3">
            <h2 class="text-blue-400 font-semibold flex items-center space-x-2"><i data-feather="repeat"></i><span>Auto Payouts</span></h2>
            <label class="flex items-center cursor-pointer">
                <div class="relative">
                    <input type="checkbox" checked class="sr-only peer">
                    <div class="w-11 h-6 bg-gray-700 rounded-full peer peer-checked:bg-blue-500 transition-all"></div>
                    <div class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition peer-checked:translate-x-full"></div>
                </div>
                <span class="ml-3 text-sm">Enable Auto Payouts</span>
            </label>
            <button onclick="showToast('✅ Auto payouts updated')" class="w-full bg-blue-500 hover:bg-blue-600 transition text-white font-semibold py-2 rounded">Update</button>
        </div>
    </div>

    <!-- Advanced Settings Table -->
    <div class="glass-card rounded-xl p-6 space-y-4 mt-6 bg-white/10 backdrop-blur shadow-lg transition hover:shadow-2xl border border-white/10">
    <div class="flex justify-between items-center">
        <h2 class="text-green-400 font-semibold text-lg flex items-center space-x-2">
            <i data-feather="sliders" class="w-5 h-5"></i>
            <span>Advanced Admin Controls</span>
        </h2>
        <button onclick="showToast('✨ Add setting clicked')" class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 transition text-white font-semibold px-4 py-2 rounded flex items-center space-x-1 shadow">
            <i data-feather="plus" class="w-4 h-4"></i>
            <span>Add Setting</span>
        </button>
    </div>

    <div class="overflow-x-auto rounded-xl">
        <table class="min-w-full text-left text-sm bg-white/5 backdrop-blur rounded-xl overflow-hidden">
            <thead class="bg-gray-800 text-gray-300">
                <tr>
                    <th class="px-4 py-3">Setting</th>
                    <th class="px-4 py-3">Current Value</th>
                    <th class="px-4 py-3">Status</th>
                    <th class="px-4 py-3">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-700">
                <tr class="hover:bg-gray-700/50 transition">
                    <td class="px-4 py-3">Referral Bonus (%)</td>
                    <td class="px-4 py-3">5%</td>
                    <td class="px-4 py-3 text-green-400">Active</td>
                    <td class="px-4 py-3 space-x-2 flex items-center">
                        <button onclick="showToast('⚙️ Edit clicked')" class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded flex items-center space-x-1">
                            <i data-feather="edit-3" class="w-4 h-4"></i>
                            <span>Edit</span>
                        </button>
                        <button onclick="showToast('❌ Disabled')" class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded flex items-center space-x-1">
                            <i data-feather="x-circle" class="w-4 h-4"></i>
                            <span>Disable</span>
                        </button>
                    </td>
                </tr>
                <tr class="hover:bg-gray-700/50 transition">
                    <td class="px-4 py-3">Max Contest Join Limit</td>
                    <td class="px-4 py-3">500</td>
                    <td class="px-4 py-3 text-green-400">Active</td>
                    <td class="px-4 py-3 space-x-2 flex items-center">
                        <button onclick="showToast('⚙️ Edit clicked')" class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded flex items-center space-x-1">
                            <i data-feather="edit-3" class="w-4 h-4"></i>
                            <span>Edit</span>
                        </button>
                        <button onclick="showToast('❌ Disabled')" class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded flex items-center space-x-1">
                            <i data-feather="x-circle" class="w-4 h-4"></i>
                            <span>Disable</span>
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
        <!-- Empty state placeholder -->
        <!--
        <div class="text-center py-6 text-gray-400">
            <i data-feather="settings" class="w-10 h-10 mx-auto mb-2"></i>
            <p>No settings configured yet.</p>
        </div>
        -->
    </div>

    <!-- Pagination placeholder -->
    <div class="flex justify-end pt-4 space-x-2">
        <button class="bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-1 rounded text-xs">Previous</button>
        <button class="bg-gray-700 hover:bg-gray-600 text-gray-300 px-3 py-1 rounded text-xs">Next</button>
    </div>
</div>

<script>
    feather.replace();
</script>

</main>

<!-- Floating Action Button -->
<button onclick="showToast('✨ Add New Setting Floating Button Clicked')" class="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white rounded-full p-4 shadow-lg transition transform hover:scale-105 z-40">
    <i data-feather="plus"></i>
</button>

<script>
    feather.replace();
    function showToast(message) {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 3000);
    }
</script>

</body>
</html>
