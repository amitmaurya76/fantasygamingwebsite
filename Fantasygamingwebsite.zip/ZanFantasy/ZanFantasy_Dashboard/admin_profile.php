<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Profile | Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 25px rgba(34, 197, 94, 0.15);
        }
        input { color-scheme: dark; }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 fade-in max-w-xl mx-auto space-y-6">
    <h1 class="text-2xl font-bold text-green-400 mb-4">👤 Admin Profile</h1>

    <div class="glass-card rounded-xl p-6 space-y-4 text-center">
        <img src="image/user/admin_avatar.png" alt="Admin Avatar" class="w-24 h-24 rounded-full mx-auto border-4 border-green-400 shadow">
        <h2 class="text-xl font-semibold text-white">Amit Maurya</h2>
        <p class="text-green-400">Senior Admin</p>

        <div class="space-y-4 text-left mt-4">
            <div>
                <label class="block text-gray-300 mb-1">Name</label>
                <input type="text" value="Amit Maurya" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
            </div>
            <div>
                <label class="block text-gray-300 mb-1">Email</label>
                <input type="email" value="admin@zanthium.com" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
            </div>
            <div>
                <label class="block text-gray-300 mb-1">Mobile</label>
                <input type="text" value="+91 94589 02989" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
            </div>
            <div>
                <label class="block text-gray-300 mb-1">Change Password</label>
                <input type="password" placeholder="New Password" class="w-full px-3 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
            </div>
            <button class="w-full bg-green-500 hover:bg-green-600 transition text-white font-semibold py-2 rounded">
                💾 Save Changes
            </button>
        </div>
    </div>
</main>
</body>
</html>
