<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php 'loader.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard | Zanthium</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <style>
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
        .glass-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(14px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: all 0.3s ease;
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 30px rgba(34, 197, 94, 0.15);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 fade-in space-y-6">

    <div class="flex justify-between items-center flex-wrap">
        <h1 class="text-2xl font-bold text-green-400 mb-2"><i class="fa-solid fa-house-fire"></i> Hello, Amit 👋</h1>
        <input type="text" placeholder="Search..." class="px-4 py-2 rounded bg-gray-700 border border-gray-600 focus:outline-none focus:border-green-400">
    </div>

    <!-- Stat Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="glass-card rounded-lg p-5 text-center">
            <h2 class="text-sm text-gray-300">Total Users</h2>
            <p class="text-2xl font-bold text-green-400">34M <span class="text-green-500 text-sm">+7%</span></p>
        </div>
        <div class="glass-card rounded-lg p-5 text-center">
            <h2 class="text-sm text-gray-300">Total Bidding Users</h2>
            <p class="text-2xl font-bold text-yellow-400">3M <span class="text-green-500 text-sm">+7%</span></p>
        </div>
        <div class="glass-card rounded-lg p-5 text-center">
            <h2 class="text-sm text-gray-300">Revenue</h2>
            <p class="text-2xl font-bold text-blue-400">₹4.5Cr <span class="text-green-500 text-sm">+8%</span></p>
        </div>
        <div class="glass-card rounded-lg p-5 text-center">
            <h2 class="text-sm text-gray-300">Matches Played</h2>
            <p class="text-2xl font-bold text-pink-400">348 <span class="text-green-500 text-sm">+7%</span></p>
        </div>
    </div>

    <!-- Charts Section -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div class="glass-card rounded-lg p-4">
            <h2 class="text-green-400 font-semibold mb-2"><i class="fa-solid fa-chart-line"></i> Revenue Trends</h2>
            <canvas id="revenueChart" height="200"></canvas>
        </div>
        <div class="glass-card rounded-lg p-4">
            <h2 class="text-green-400 font-semibold mb-2"><i class="fa-solid fa-arrow-trend-up"></i> Matches Trend</h2>
            <canvas id="matchesChart" height="200"></canvas>
        </div>
    </div>

    <!-- Live Matches Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php for($i=0; $i<2; $i++): ?>
        <div class="glass-card rounded-xl p-4 space-y-3">
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-300">Group B | 1M Players</span>
                <button class="text-gray-400 hover:text-white">⋮</button>
            </div>
            <div class="flex justify-between items-center">
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/de.png" alt="Team1" class="inline-block mb-1">
                    <p class="text-sm">Bayern</p>
                </div>
                <div class="text-center text-2xl font-bold">3 - 2</div>
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/gb.png" alt="Team2" class="inline-block mb-1">
                    <p class="text-sm">Man Utd</p>
                </div>
            </div>
            <div class="flex justify-between text-xs text-gray-300">
                <p>78% Bayern</p>
                <p>22% Man Utd</p>
            </div>
            <div class="text-xs text-gray-400">20M Players already bid</div>
            <div class="flex space-x-2">
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
                <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
            </div>
        </div>
        <div class="glass-card rounded-xl p-4 space-y-3">
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-300">Group A | 2M Players</span>
                <button class="text-gray-400 hover:text-white">⋮</button>
            </div>
            <div class="flex justify-between items-center">
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/in.png" alt="Team1" class="inline-block mb-1">
                    <p class="text-sm">India</p>
                </div>
                <div class="text-center text-2xl font-bold">5 - 1</div>
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/pk.png" alt="Team2" class="inline-block mb-1">
                    <p class="text-sm">Pakistan</p>
                </div>
            </div>
            <div class="flex justify-between text-xs text-gray-300">
                <p>78% Bayern</p>
                <p>22% Man Utd</p>
            </div>
            <div class="text-xs text-gray-400">23M Players already bid</div>
            <div class="flex space-x-2">
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
                <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
            </div>
        </div>
        <div class="glass-card rounded-xl p-4 space-y-3">
            <div class="flex justify-between items-center">
                <span class="text-sm text-gray-300">Group C | 3M Players</span>
                <button class="text-gray-400 hover:text-white">⋮</button>
            </div>
            <div class="flex justify-between items-center">
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/nz.png" alt="Team1" class="inline-block mb-1">
                    <p class="text-sm">New Zealand</p>
                </div>
                <div class="text-center text-2xl font-bold">5 - 4</div>
                <div class="text-center">
                    <img src="https://flagcdn.com/w20/in.png" alt="Team2" class="inline-block mb-1">
                    <p class="text-sm">India</p>
                </div>
            </div>
            <div class="flex justify-between text-xs text-gray-300">
                <p>78% Bayern</p>
                <p>22% Man Utd</p>
            </div>
            <div class="text-xs text-gray-400">23M Players already bid</div>
            <div class="flex space-x-2">
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">1x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">2x</button>
                <button class="flex-1 bg-green-600 hover:bg-green-700 text-xs rounded px-2 py-1">3x</button>
                <button class="flex-1 bg-blue-600 hover:bg-blue-700 text-xs rounded px-2 py-1">Custom</button>
            </div>
        </div>
        <?php endfor; ?>
    </div>


    <!-- To-Do Card -->
    <div class="glass-card rounded-lg p-6 space-y-3">
        <div class="flex justify-between items-center">
            <h2 class="text-green-400 font-semibold text-lg"><i class="fa-solid fa-circle-check"></i> To Do List</h2>
            <button class="bg-green-500 hover:bg-green-600 transition text-white font-semibold px-4 py-2 rounded text-sm">+ Add Task</button>
        </div>
        <div class="bg-gray-700 p-3 rounded flex items-center justify-between">
            <p class="text-sm text-gray-300">Complete KYC Review for 12 users</p>
            <button class="text-green-400 text-sm">Mark Done</button>
        </div>
        <div class="bg-gray-700 p-3 rounded flex items-center justify-between">
            <p class="text-sm text-gray-300">Check Payment Gateway Settlements</p>
            <button class="text-green-400 text-sm">Mark Done</button>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

        <!-- League Card -->
        <!-- Cricket Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded">LIVE</div>
            <img src="image/cricket.png" alt="Cricket" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center"><i class="fa-solid fa-baseball-bat-ball"></i> IPL Mega Contest</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹5,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹49 | Spots: 2,000/5,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-green-400 h-2 rounded-full" style="width: 40%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Football Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-0.5 rounded">UPCOMING</div>
            <img src="image/football.png" alt="Football" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center"><i class="fa-solid fa-futbol"></i> Football Mega Contest </h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹2,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹29 | Spots: 500/2,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-yellow-400 h-2 rounded-full" style="width: 25%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Basketball Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-purple-500 text-white text-xs px-2 py-0.5 rounded">COMPLETED</div>
            <img src="image/basketball.png" alt="Basketball" class="w-34 h-18 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center"><i class="fa-solid fa-basketball"></i> Pro Basketball League</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹1,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹19 | Spots: 1,000/1,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-purple-400 h-2 rounded-full" style="width: 100%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">View</button>
                <button class="bg-blue-500 hover:bg-blue-600 transition text-white text-xs px-3 py-1 rounded">Details</button>
            </div>
        </div>

        <!-- Kabaddi Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded">LIVE</div>
            <img src="image/kabaddi.png" alt="Kabaddi" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center">🤼 Kabaddi Clash</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹50,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹15 | Spots: 300/800</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-green-400 h-2 rounded-full" style="width: 37%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Add additional league cards dynamically here later -->

    </div>

</main>

<!-- Charts -->
<script>
const ctx1 = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
        datasets: [{
            label: 'Revenue (₹)',
            data: [400000, 450000, 500000, 600000, 550000, 700000, 800000],
            backgroundColor: 'rgba(34, 197, 94, 0.2)',
            borderColor: 'rgba(34, 197, 94, 1)',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
            pointRadius: 4,
            pointBackgroundColor: 'rgba(34, 197, 94, 1)'
        }]
    },
    options: { scales: { y: { beginAtZero: true } } }
});

const ctx2 = document.getElementById('matchesChart').getContext('2d');
new Chart(ctx2, {
    type: 'bar',
    data: {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        datasets: [{
            label: 'Matches Played',
            data: [120, 150, 180, 200],
            backgroundColor: 'rgba(59, 130, 246, 0.6)',
            borderColor: 'rgba(59, 130, 246, 1)',
            borderWidth: 1
        }]
    },
    options: { scales: { y: { beginAtZero: true } } }
});
</script>

</body>
</html>
