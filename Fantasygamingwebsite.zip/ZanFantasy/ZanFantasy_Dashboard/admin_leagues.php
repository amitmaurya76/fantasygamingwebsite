<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin - Leagues | Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <style>
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
        .glow-card {
            background: rgba(31, 41, 55, 0.6);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }
        .glow-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 25px rgba(34, 197, 94, 0.25);
        }
    </style>
</head>

<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 fade-in space-y-6">

    <h1 class="text-2xl font-bold text-green-400 mb-4"><i class="fa-solid fa-trophy"></i> League Management</h1>

    <!-- Search & Filter -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
        <input type="text" placeholder="🔍 Search by league name..." class="w-full md:w-1/3 px-3 py-2 rounded bg-gray-800 border border-gray-700 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
        <select class="w-full md:w-1/4 px-3 py-2 rounded bg-gray-800 border border-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-green-400 transition">
            <option value="">Filter by Status</option>
            <option value="active">Active</option>
            <option value="closed">Closed</option>
        </select>
        <button class="bg-green-600 hover:bg-green-700 px-4 py-2 rounded text-sm transition">Reset Filters</button>
    </div>

    <!-- League Cards Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">

        <!-- League Card -->
        <!-- Cricket Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded">LIVE</div>
            <img src="image/cricket.png" alt="Cricket" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center">🏏 IPL Mega Contest</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹5,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹49 | Spots: 2,000/5,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-green-400 h-2 rounded-full" style="width: 40%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Football Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-yellow-500 text-white text-xs px-2 py-0.5 rounded">UPCOMING</div>
            <img src="image/football.png" alt="Football" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center">⚽ Football Mega Contest </h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹2,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹29 | Spots: 500/2,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-yellow-400 h-2 rounded-full" style="width: 25%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Basketball Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-purple-500 text-white text-xs px-2 py-0.5 rounded">COMPLETED</div>
            <img src="image/basketball.png" alt="Basketball" class="w-34 h-18 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center">🏀 Pro Basketball League</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹1,00,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹19 | Spots: 1,000/1,000</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-purple-400 h-2 rounded-full" style="width: 100%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">View</button>
                <button class="bg-blue-500 hover:bg-blue-600 transition text-white text-xs px-3 py-1 rounded">Details</button>
            </div>
        </div>

        <!-- Kabaddi Contest Card -->
        <div class="bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden">
            <div class="absolute top-2 right-2 bg-green-500 text-white text-xs px-2 py-0.5 rounded">LIVE</div>
            <img src="image/kabaddi.png" alt="Kabaddi" class="w-42 h-22 mb-2 rounded-t-lg mx-auto">
            <h3 class="text-white font-semibold text-center">🤼 Kabaddi Clash</h3>
            <p class="text-gray-300 text-sm text-center">Prize Pool: ₹50,000</p>
            <p class="text-gray-300 text-sm text-center">Entry: ₹15 | Spots: 300/800</p>
            <div class="w-full bg-gray-600 rounded-full h-2 mt-2">
                <div class="bg-green-400 h-2 rounded-full" style="width: 37%;"></div>
            </div>
            <div class="flex justify-center mt-2 space-x-2">
                <button class="bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded">Edit</button>
                <button class="bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded">Close</button>
            </div>
        </div>

        <!-- Add additional league cards dynamically here later -->

    </div>

    <!-- Recent League Logs -->
    <div class="glow-card rounded-lg p-4 mt-6 bg-gray-900 shadow-lg transition-transform transform hover:-translate-y-1 hover:shadow-green-500/20">
    <h2 class="text-green-400 font-semibold mb-3 text-lg flex items-center gap-2">
        <i class="fa-solid fa-clipboard-list text-green-400"></i> Recent League Logs
    </h2>
    <ul class="space-y-2 text-sm">
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-circle-check text-green-400"></i>
            <span>Mega Cricket League created with a prize pool of ₹5,000 - <span class="text-gray-400">15 min ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-trophy text-yellow-400"></i>
            <span>Weekend Football Clash updated - <span class="text-gray-400">1 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-circle-xmark text-red-400"></i>
            <span>Kabaddi Kings League closed - <span class="text-gray-400">2 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-users text-blue-400"></i>
            <span>Mega Cricket League reached 250 entries - <span class="text-gray-400">3 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-futbol text-green-300"></i>
            <span>New Football League "City Cup" created with prize pool ₹2,500 - <span class="text-gray-400">4 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-table-tennis-paddle-ball text-pink-400"></i>
            <span>Badminton Doubles League registrations opened - <span class="text-gray-400">5 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-coins text-yellow-400"></i>
            <span>Cricket Champions League updated prize pool to ₹10,000 - <span class="text-gray-400">6 hr ago</span></span>
        </li>
        <li class="bg-gray-800 hover:bg-gray-700 transition rounded px-3 py-2 flex items-center gap-2">
            <i class="fa-solid fa-circle-check text-green-400"></i>
            <span>T20 Quick League closed after reaching max entries - <span class="text-gray-400">8 hr ago</span></span>
        </li>
    </ul>
</div>


</main>

</body>
</html>
