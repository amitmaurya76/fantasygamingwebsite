<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin - Payments | Zanthium</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
        .glass-card {
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
            transition: all 0.3s ease;
        }
        .glass-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 15px 25px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 fade-in space-y-6">

    <!-- Header -->
    <div class="flex flex-col md:flex-row md:justify-between md:items-center">
        <h1 class="text-2xl font-bold text-green-400 mb-2"><i class="fa-solid fa-money-bill-transfer"></i> Payment Monitoring</h1>
        <div class="flex space-x-2">
            <input type="text" placeholder="🔍 Search transactions..." class="px-3 py-2 rounded bg-gray-800 border border-gray-700 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
            <select class="px-3 py-2 rounded bg-gray-800 border border-gray-700 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
                <option>All</option>
                <option>Pending</option>
                <option>Completed</option>
                <option>Failed</option>
            </select>
        </div>
    </div>

    <!-- Overview Cards -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="glass-card rounded-xl p-4 text-center">
            <p class="text-gray-300 text-sm">Total Transactions</p>
            <p class="text-2xl font-bold text-green-400">₹5,40,000</p>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <p class="text-gray-300 text-sm">Pending Withdrawals</p>
            <p class="text-2xl font-bold text-yellow-400">₹45,000</p>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <p class="text-gray-300 text-sm">Completed Withdrawals</p>
            <p class="text-2xl font-bold text-blue-400">₹4,50,000</p>
        </div>
        <div class="glass-card rounded-xl p-4 text-center">
            <p class="text-gray-300 text-sm">Failed Transactions</p>
            <p class="text-2xl font-bold text-red-400">₹5,000</p>
        </div>
    </div>

    <!-- Recent Transactions Table -->
    <div class="glass-card rounded-xl p-4 mt-4 overflow-x-auto bg-gray-900 shadow-lg transition-transform transform hover:-translate-y-1 hover:shadow-green-500/20">
    <div class="flex justify-between items-center mb-3">
        <h2 class="text-green-400 font-semibold text-lg flex items-center gap-2">
            <i class="fa-solid fa-money-check-dollar text-green-400"></i> Recent Transactions
        </h2>
        <div class="flex space-x-2">
            <button class="bg-gray-700 hover:bg-gray-600 transition px-3 py-1 rounded text-xs flex items-center gap-1">
                <i class="fa-solid fa-file-csv"></i> Export CSV
            </button>
            <button class="bg-gray-700 hover:bg-gray-600 transition px-3 py-1 rounded text-xs flex items-center gap-1">
                <i class="fa-solid fa-sort"></i> Sort
            </button>
            <button class="bg-gray-700 hover:bg-gray-600 transition px-3 py-1 rounded text-xs flex items-center gap-1">
                <i class="fa-solid fa-filter"></i> Filter
            </button>
        </div>
    </div>

    <table class="min-w-full text-left text-sm">
        <thead class="bg-gray-700 text-gray-300 uppercase text-xs tracking-wider">
            <tr>
                <th class="px-4 py-3">User</th>
                <th class="px-4 py-3">Amount</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Date</th>
                <th class="px-4 py-3 text-center">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-700">
            <?php
            $statuses = [
                'Completed' => 'text-blue-400',
                'Pending' => 'text-yellow-400',
                'Failed' => 'text-red-400'
            ];
            $dummy_users = [
                ['Amit Maurya', '₹5,000', 'Completed', '2025-07-08'],
                ['Priya Yadav', '₹1,200', 'Pending', '2025-07-07'],
                ['Ravi Singh', '₹3,500', 'Failed', '2025-07-06'],
                ['Meena Kumari', '₹7,500', 'Completed', '2025-07-05'],
                ['Vikas Sharma', '₹2,000', 'Pending', '2025-07-04'],
                ['Anjali Verma', '₹4,800', 'Completed', '2025-07-03'],
                ['Rahul Tiwari', '₹3,100', 'Failed', '2025-07-02'],
                ['Sneha Sinha', '₹6,200', 'Completed', '2025-07-01'],
                ['Kunal Mehta', '₹950', 'Pending', '2025-06-30'],
                ['Shreya Patel', '₹2,700', 'Completed', '2025-06-29'],
                ['Deepak Chaurasia', '₹1,500', 'Failed', '2025-06-28'],
                ['Nisha Rani', '₹3,900', 'Completed', '2025-06-27'],
                ['Rohit Das', '₹2,300', 'Pending', '2025-06-26'],
                ['Tanya Gupta', '₹4,400', 'Completed', '2025-06-25'],
                ['Arjun Kapoor', '₹1,850', 'Failed', '2025-06-24'],
                ['Divya Shah', '₹5,100', 'Completed', '2025-06-23'],
                ['Manoj Bhatia', '₹2,650', 'Pending', '2025-06-22'],
                ['Pooja Kaur', '₹3,300', 'Completed', '2025-06-21'],
                ['Sahil Khan', '₹4,000', 'Failed', '2025-06-20'],
                ['Kritika Joshi', '₹3,750', 'Completed', '2025-06-19'],
            ];
            foreach ($dummy_users as $tx) {
                echo "<tr class='hover:bg-gray-800 transition duration-200 ease-in-out'>
                    <td class='px-4 py-3 font-semibold text-white'>{$tx[0]}</td>
                    <td class='px-4 py-3 text-yellow-300 font-medium'>{$tx[1]}</td>
                    <td class='px-4 py-3 {$statuses[$tx[2]]}'>{$tx[2]}</td>
                    <td class='px-4 py-3 text-gray-400'>{$tx[3]}</td>
                    <td class='px-4 py-3 flex justify-center gap-2'>
                        <button class='text-blue-400 hover:text-blue-500 transition' title='View'>
                            <i class='fa-solid fa-eye'></i>
                        </button>
                        <button class='text-green-400 hover:text-green-500 transition' title='Approve'>
                            <i class='fa-solid fa-circle-check'></i>
                        </button>
                        <button class='text-red-400 hover:text-red-500 transition' title='Delete'>
                            <i class='fa-solid fa-trash'></i>
                        </button>
                    </td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>



</main>
</body>
</html>
