<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1d3138, #2c5364, #000000);
        }
        .card {
            background: linear-gradient(135deg, #263d4b, #1d3138);
            border-radius: 1rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.08);
        }
        .input {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #f0f4f8;
            transition: all 0.3s ease;
        }
        .input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        .input:focus {
            border-color: #22c55e;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.3);
            background: rgba(255, 255, 255, 0.08);
        }
        .button {
            background: linear-gradient(to right, #22c55e, #16a34a);
            transition: all 0.3s ease;
        }
        .button:hover {
            background: linear-gradient(to right, #16a34a, #15803d);
            transform: translateY(-1px);
        }
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.6s ease-out;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen relative">

<div class="card p-6 w-full max-w-sm mx-4 animate-fade-in">
    <div class="flex justify-center mb-4">
        <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12">
    </div>
    <h2 class="text-center text-2xl font-bold text-white mb-2">Create an Account</h2>

    <?php 
    session_start(); 
    if (isset($_SESSION['error'])) { ?>
        <p class="text-red-400 text-sm text-center mb-2">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </p>
    <?php } ?>

    <form action="admin_login.php" method="POST" class="space-y-3">
        <input 
            type="text" 
            name="name" 
            placeholder="Full Name" 
            required 
            class="input w-full px-3 py-2 rounded focus:outline-none"
        >
        <input 
            type="text" 
            name="email" 
            placeholder="Email or Mobile" 
            required 
            class="input w-full px-3 py-2 rounded focus:outline-none"
        >
        <input 
            type="password" 
            name="password" 
            placeholder="Password" 
            required 
            class="input w-full px-3 py-2 rounded focus:outline-none"
        >
        <button 
            type="submit" 
            class="button w-full text-white font-semibold py-2 rounded shadow"
        >
            Register
        </button>
    </form>

    <p class="text-xs text-gray-300 text-center mt-3">
        Already have an account? 
        <a href="admin_login.php" class="text-green-400 hover:underline">Login</a>
    </p>
</div>

</body>
</html>
