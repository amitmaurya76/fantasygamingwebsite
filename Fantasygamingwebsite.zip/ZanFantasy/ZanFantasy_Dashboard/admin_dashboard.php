<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link rel="icon" href="image/favicon.ico" type="image/x-icon" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.6s ease-out;
        }
        .glow-card:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 15px 25px rgba(34, 197, 94, 0.3);
            transition: all 0.3s ease;
        }
    </style>
</head>

<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 space-y-6 animate-fade-in">
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-green-600 rounded-xl p-5 glow-card text-center shadow-md">
            <p class="text-sm">Total Users</p>
            <p class="text-3xl font-bold">1,250</p>
        </div>
        <div class="bg-blue-600 rounded-xl p-5 glow-card text-center shadow-md">
            <p class="text-sm">Active Leagues</p>
            <p class="text-3xl font-bold">95</p>
        </div>
        <div class="bg-yellow-600 rounded-xl p-5 glow-card text-center shadow-md">
            <p class="text-sm">Total Earnings</p>
            <p class="text-3xl font-bold">₹3.5L</p>
        </div>
        <div class="bg-red-600 rounded-xl p-5 glow-card text-center shadow-md">
            <p class="text-sm">Withdrawals</p>
            <p class="text-3xl font-bold">₹1.2L</p>
        </div>
    </div>

    <div class="bg-gray-800 rounded-xl p-6 shadow-md">
        <h2 class="text-green-400 font-semibold mb-4"><i class="fa-solid fa-chart-simple"></i> Earnings Overview</h2>
        <canvas id="earningsChart" height="100"></canvas>
    </div>

    <div class="bg-gray-800 rounded-xl p-6 shadow-md">
        <h2 class="text-green-400 font-semibold mb-4"><i class="fa-solid fa-user-plus"></i> Recent Users</h2>
        <div class="overflow-x-auto rounded-md">
            <table class="min-w-full bg-gray-900 rounded-md text-left text-sm">
    <thead class="bg-gray-700 text-gray-300">
        <tr>
            <th class="px-4 py-3">Name</th>
            <th class="px-4 py-3">Email</th>
            <th class="px-4 py-3">Joined</th>
        </tr>
    </thead>
    <tbody class="divide-y divide-gray-700">
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Amit Maurya</td>
            <td class="px-4 py-2">amit@example.com</td>
            <td class="px-4 py-2">2025-07-07</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Ravi Singh</td>
            <td class="px-4 py-2">ravi@example.com</td>
            <td class="px-4 py-2">2025-07-06</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Priya Yadav</td>
            <td class="px-4 py-2">priya@example.com</td>
            <td class="px-4 py-2">2025-07-05</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Sneha Patel</td>
            <td class="px-4 py-2">sneha@example.com</td>
            <td class="px-4 py-2">2025-07-05</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Rahul Sharma</td>
            <td class="px-4 py-2">rahul@example.com</td>
            <td class="px-4 py-2">2025-07-04</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Megha Joshi</td>
            <td class="px-4 py-2">megha@example.com</td>
            <td class="px-4 py-2">2025-07-03</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Karan Singh</td>
            <td class="px-4 py-2">karan@example.com</td>
            <td class="px-4 py-2">2025-07-03</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Divya Rathi</td>
            <td class="px-4 py-2">divya@example.com</td>
            <td class="px-4 py-2">2025-07-02</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Nikhil Kapoor</td>
            <td class="px-4 py-2">nikhil@example.com</td>
            <td class="px-4 py-2">2025-07-01</td>
        </tr>
        <tr class="hover:bg-gray-700 transition">
            <td class="px-4 py-2">Ananya Verma</td>
            <td class="px-4 py-2">ananya@example.com</td>
            <td class="px-4 py-2">2025-07-01</td>
        </tr>
    </tbody>
</table>

        </div>
    </div>
</main>

<script>
    const ctx = document.getElementById('earningsChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
            datasets: [{
                label: 'Earnings (₹)',
                data: [45000, 50000, 60000, 55000, 70000, 80000, 90000],
                backgroundColor: 'rgba(34, 197, 94, 0.2)',
                borderColor: 'rgba(34, 197, 94, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 4,
                pointBackgroundColor: 'rgba(34, 197, 94, 1)',
            }]
        },
        options: {
            scales: {
                y: { beginAtZero: true },
                x: { grid: { color: '#374151' }, ticks: { color: '#d1d5db' } },
                y: { grid: { color: '#374151' }, ticks: { color: '#d1d5db' } }
            },
            plugins: {
                legend: { labels: { color: '#d1d5db' } }
            }
        }
    });
</script>

</body>
</html>
