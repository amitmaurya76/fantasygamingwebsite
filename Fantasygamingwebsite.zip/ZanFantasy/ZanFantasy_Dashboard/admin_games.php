<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Game Management | Zanthium</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="icon" href="image/favicon.ico" type="image/x-icon">
<style>
.fade-in { animation: fadeIn 0.5s ease-in-out; }
@keyframes fadeIn { from {opacity:0; transform: translateY(10px);} to {opacity:1; transform: translateY(0);} }
.glass-card {
    background: rgba(255, 255, 255, 0.05);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
}
.glass-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 15px 25px rgba(34, 197, 94, 0.15);
}
</style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<?php include 'loader.php'; ?>

<main class="p-4 md:ml-64 fade-in space-y-6">
<h1 class="text-2xl font-bold text-green-400 mb-4"><i class="fa-solid fa-gamepad text-green-400 mr-1"></i> Game Management</h1>

<!-- Metric Glass Cards -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
    <div class="glass-card rounded-lg p-4 text-center">
        <h2 class="text-lg font-semibold text-green-400"><i class="fa-solid fa-bolt mr-1"></i> Live Contests</h2>
        <p class="text-3xl font-bold">12</p>
    </div>
    <div class="glass-card rounded-lg p-4 text-center">
        <h2 class="text-lg font-semibold text-yellow-400"><i class="fa-solid fa-hourglass-half mr-1"></i> Upcoming Contests</h2>
        <p class="text-3xl font-bold">10</p>
    </div>
    <div class="glass-card rounded-lg p-4 text-center">
        <h2 class="text-lg font-semibold text-blue-400"><i class="fa-solid fa-circle-check mr-1"></i> Completed Contests</h2>
        <p class="text-3xl font-bold">61</p>
    </div>
    <div class="glass-card rounded-lg p-4 text-center">
        <h2 class="text-lg font-semibold text-purple-400"><i class="fa-solid fa-users mr-1"></i> Total Users</h2>
        <p class="text-3xl font-bold">4,350</p>
    </div>
</div>

<!-- Game Performance Chart -->
<div class="glass-card rounded-lg p-6">
    <h2 class="text-green-400 font-semibold mb-4"><i class="fa-solid fa-chart-line mr-1"></i> Game Performance Overview</h2>
    <canvas id="gamePerformanceChart" height="120"></canvas>
</div>

<!-- Active Tournaments and Contests -->
<div class="glass-card rounded-lg p-6 space-y-4">
    <div class="flex justify-between items-center">
        <h2 class="text-green-400 font-semibold text-lg"><i class="fa-solid fa-trophy mr-1"></i> Active Tournaments</h2>
        <button class="bg-green-500 hover:bg-green-600 transition text-white font-semibold px-4 py-2 rounded"><i class="fa-solid fa-plus mr-1"></i> Add New Contest</button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">

        <!-- Dynamic Contest Cards -->
        <?php
        $contests = [
            ['LIVE', 'green-500', 'image/cricket.png', '🏏 IPL Mega Contest', '₹5,00,000', '₹49', '2,000/5,000', 40],
            ['UPCOMING', 'yellow-500', 'image/football.png', '⚽ Football Mega Contest', '₹2,00,000', '₹29', '500/2,000', 25],
            ['COMPLETED', 'purple-500', 'image/basketball.png', '🏀 Pro Basketball League', '₹1,00,000', '₹19', '1,000/1,000', 100],
            ['LIVE', 'green-500', 'image/kabaddi.png', '🤼 Kabaddi Clash', '₹50,000', '₹15', '300/800', 37],
            ['UPCOMING', 'yellow-500', 'image/cricket2.png', '🏏 T20 IWC', '₹75,000', '₹25', '150/600', 25],
            ['UPCOMING', 'yellow-500', 'image/cricket4.png', '🏆 ICC IWC', '₹7,50,000', '₹99', '1,500/4,000', 37],
        ];
        foreach ($contests as $c) {
            echo "
            <div class='bg-gray-800 rounded-lg p-4 hover:bg-gray-700 transition relative overflow-hidden'>
                <div class='absolute top-2 right-2 bg-{$c[1]} text-white text-xs px-2 py-0.5 rounded'>{$c[0]}</div>
                <img src='{$c[2]}' alt='{$c[3]}' class='w-42 h-22 mb-2 rounded-t-lg mx-auto'>
                <h3 class='text-white font-semibold text-center'>{$c[3]}</h3>
                <p class='text-gray-300 text-sm text-center'>Prize Pool: {$c[4]}</p>
                <p class='text-gray-300 text-sm text-center'>Entry: {$c[5]} | Spots: {$c[6]}</p>
                <div class='w-full bg-gray-600 rounded-full h-2 mt-2'>
                    <div class='bg-green-400 h-2 rounded-full' style='width: {$c[7]}%;'></div>
                </div>
                <div class='flex justify-center mt-2 space-x-2'>
                    <button class='bg-yellow-500 hover:bg-yellow-600 transition text-white text-xs px-3 py-1 rounded'><i class='fa-solid fa-pen-to-square mr-1'></i> Edit</button>
                    <button class='bg-red-500 hover:bg-red-600 transition text-white text-xs px-3 py-1 rounded'><i class='fa-solid fa-xmark mr-1'></i> Close</button>
                </div>
            </div>
            ";
        }
        ?>
    </div>
</div>

</main>

<script>
const ctx = document.getElementById('gamePerformanceChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Football', 'Cricket', 'Basketball', 'Kabaddi'],
        datasets: [{
            label: 'Active Contests',
            data: [40, 55, 25, 20],
            backgroundColor: [
                'rgba(34, 197, 94, 0.7)',
                'rgba(59, 130, 246, 0.7)',
                'rgba(245, 158, 11, 0.7)',
                'rgba(139, 92, 246, 0.7)',
                'rgba(239, 68, 68, 0.7)',
                'rgba(16, 185, 129, 0.7)',
                'rgba(168, 85, 247, 0.7)'
            ],
            borderRadius: 8
        }]
    },
    options: {
        scales: { y: { beginAtZero: true } },
        plugins: { legend: { display: false } }
    }
});
</script>
</body>
</html>
