<?php
include 'includes/admin_sidebar.php';
include 'includes/admin_topbar.php';
?>
<?php include 'loader.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Admin - Users | Zanthium</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <style>
        .glow-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 20px rgba(34, 197, 94, 0.25);
            transition: all 0.3s ease;
        }
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from { opacity:0; transform: translateY(10px); } to { opacity:1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-900 to-gray-800 text-white min-h-screen">

<main class="p-4 md:ml-64 space-y-6 fade-in">
    <h1 class="text-2xl font-bold text-green-400 mb-4"><i class="fa-solid fa-users"></i> User Management</h1>

    <!-- User Activity Overview -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-gray-800 rounded-lg p-4 glow-card text-center">
            <p class="text-sm text-gray-300">Total Contests Joined</p>
            <p class="text-2xl font-bold text-green-400">4,567</p>
        </div>
        <div class="bg-gray-800 rounded-lg p-4 glow-card text-center">
            <p class="text-sm text-gray-300">Total Deposits</p>
            <p class="text-2xl font-bold text-green-400">₹12.8L</p>
        </div>
        <div class="bg-gray-800 rounded-lg p-4 glow-card text-center">
            <p class="text-sm text-gray-300">Total Winnings Paid</p>
            <p class="text-2xl font-bold text-green-400">₹7.3L</p>
        </div>
    </div>

    <!-- Search & Filter -->
    <div class="bg-gray-800 rounded-lg p-4 glow-card">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
            <input type="text" placeholder="Search by name, email, or mobile..." class="w-full md:w-1/3 px-3 py-2 rounded bg-gray-700 border border-gray-600 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-green-400 transition">
            <select class="w-full md:w-1/4 px-3 py-2 rounded bg-gray-700 border border-gray-600 text-white focus:outline-none focus:ring-2 focus:ring-green-400 transition">
                <option value="">Filter by Status</option>
                <option value="active">Active</option>
                <option value="pending">Pending</option>
                <option value="blocked">Blocked</option>
            </select>
            <button class="bg-green-600 hover:bg-green-700 transition px-4 py-2 rounded text-sm">Reset Filters</button>
        </div>
    </div>

    <!-- User Table -->
    <div class="bg-gray-800 rounded-xl p-4 overflow-x-auto glow-card shadow-md transition">
    <table class="min-w-full text-sm text-left">
        <thead class="bg-gray-700 text-gray-300 uppercase text-xs tracking-wider">
            <tr>
                <th class="px-4 py-3">#</th>
                <th class="px-4 py-3">Name</th>
                <th class="px-4 py-3">Email</th>
                <th class="px-4 py-3">Fantasy Points</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Joined</th>
                <th class="px-4 py-3 text-center">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-600">
            <tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
                <td class="px-4 py-3 font-medium text-gray-300">1</td>
                <td class="px-4 py-3 font-semibold text-white">Amit Maurya</td>
                <td class="px-4 py-3 text-gray-400">amit@example.com</td>
                <td class="px-4 py-3 text-yellow-300 font-semibold">8,950</td>
                <td class="px-4 py-3">
                    <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
                </td>
                <td class="px-4 py-3 text-gray-400">2025-07-08</td>
                <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
                    <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
                    <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
                    <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
                </td>
            </tr>

            <tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
                <td class="px-4 py-3 font-medium text-gray-300">2</td>
                <td class="px-4 py-3 font-semibold text-white">Priya Yadav</td>
                <td class="px-4 py-3 text-gray-400">priya@example.com</td>
                <td class="px-4 py-3 text-yellow-300 font-semibold">6,320</td>
                <td class="px-4 py-3">
                    <span class="bg-yellow-500 text-white text-xs px-2 py-0.5 rounded-full">Pending</span>
                </td>
                <td class="px-4 py-3 text-gray-400">2025-07-07</td>
                <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
                    <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
                    <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Verify</button>
                    <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
                </td>
            </tr>

            <tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
                <td class="px-4 py-3 font-medium text-gray-300">3</td>
                <td class="px-4 py-3 font-semibold text-white">Ravi Singh</td>
                <td class="px-4 py-3 text-gray-400">ravi@example.com</td>
                <td class="px-4 py-3 text-yellow-300 font-semibold">12,450</td>
                <td class="px-4 py-3">
                    <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
                </td>
                <td class="px-4 py-3 text-gray-400">2025-07-06</td>
                <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
                    <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
                    <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
                    <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
                </td>
            </tr>
            <tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">4</td>
    <td class="px-4 py-3 font-semibold text-white">Sneha Patel</td>
    <td class="px-4 py-3 text-gray-400">sneha.patel@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">7,230</td>
    <td class="px-4 py-3">
        <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-07-05</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">5</td>
    <td class="px-4 py-3 font-semibold text-white">Rahul Sharma</td>
    <td class="px-4 py-3 text-gray-400">rahul.sharma@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">5,610</td>
    <td class="px-4 py-3">
        <span class="bg-yellow-500 text-white text-xs px-2 py-0.5 rounded-full">Pending</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-07-04</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Verify</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">6</td>
    <td class="px-4 py-3 font-semibold text-white">Ananya Verma</td>
    <td class="px-4 py-3 text-gray-400">ananya.verma@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">10,820</td>
    <td class="px-4 py-3">
        <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-07-03</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">7</td>
    <td class="px-4 py-3 font-semibold text-white">Karan Singh</td>
    <td class="px-4 py-3 text-gray-400">karan.singh@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">9,300</td>
    <td class="px-4 py-3">
        <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-07-02</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">8</td>
    <td class="px-4 py-3 font-semibold text-white">Megha Joshi</td>
    <td class="px-4 py-3 text-gray-400">megha.joshi@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">4,780</td>
    <td class="px-4 py-3">
        <span class="bg-yellow-500 text-white text-xs px-2 py-0.5 rounded-full">Pending</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-07-01</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Verify</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">9</td>
    <td class="px-4 py-3 font-semibold text-white">Nikhil Kapoor</td>
    <td class="px-4 py-3 text-gray-400">nikhil.kapoor@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">11,100</td>
    <td class="px-4 py-3">
        <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-06-30</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

<tr class="hover:bg-gray-700 transition duration-200 ease-in-out">
    <td class="px-4 py-3 font-medium text-gray-300">10</td>
    <td class="px-4 py-3 font-semibold text-white">Divya Rathi</td>
    <td class="px-4 py-3 text-gray-400">divya.rathi@example.com</td>
    <td class="px-4 py-3 text-yellow-300 font-semibold">6,850</td>
    <td class="px-4 py-3">
        <span class="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Active</span>
    </td>
    <td class="px-4 py-3 text-gray-400">2025-06-29</td>
    <td class="px-4 py-3 flex justify-center gap-1 flex-wrap">
        <button class="bg-blue-500 hover:bg-blue-600 transition px-3 py-1 rounded text-xs">View</button>
        <button class="bg-yellow-500 hover:bg-yellow-600 transition px-3 py-1 rounded text-xs">Edit</button>
        <button class="bg-red-500 hover:bg-red-600 transition px-3 py-1 rounded text-xs">Block</button>
    </td>
</tr>

        </tbody>
    </table>
</div>


    <!-- Recent Activity Logs -->
    <div class="bg-gray-800 rounded-lg p-4 glow-card">
        <h2 class="text-green-400 font-semibold mb-3"><i class="fa-solid fa-clipboard"></i> Recent Activity Logs</h2>
        <ul class="space-y-2 text-sm">
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-circle-check text-green-400 mr-1"></i> Amit Maurya joined the “Mega Contest” (Cricket) with ₹50 - 5 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-money-bill-transfer text-yellow-400 mr-1"></i> Priya Yadav requested withdrawal of ₹500 - 20 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-marker text-blue-400 mr-1"></i> Ravi Singh updated profile details - 45 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-circle-check text-green-400 mr-1"></i> Sneha Patel joined the “Weekend Football League” with ₹100 - 1 hr ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-gift text-pink-400 mr-1"></i> Rahul Sharma received a referral bonus of ₹150 - 1 hr 20 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-circle-check text-green-400 mr-1"></i> Ananya Verma joined the “Daily Kabaddi Challenge” with ₹70 - 2 hr ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-money-bill-transfer text-yellow-400 mr-1"></i> Megha Joshi requested withdrawal of ₹300 - 2 hr 30 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-trophy text-purple-400 mr-1"></i> Nikhil Kapoor won ₹1200 in “Cricket Mega League” - 3 hr ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-user-plus text-blue-400 mr-1"></i> Divya Rathi registered a new account - 3 hr 45 min ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-circle-check text-green-400 mr-1"></i> Karan Singh joined the “Weekend Football League” with ₹100 - 4 hr ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-gift text-pink-400 mr-1"></i> Sneha Patel invited a friend and earned ₹100 referral bonus - 5 hr ago</li>
    <li class="bg-gray-700 rounded px-3 py-2"><i class="fa-solid fa-marker text-blue-400 mr-1"></i> Priya Yadav updated payment details - 6 hr ago</li>
</ul>

    </div>
</main>

</body>
</html>
