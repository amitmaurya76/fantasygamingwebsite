<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet"/>
  <link href="css\tailwind.min.css" rel="stylesheet"/>
<style>
     #sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
      background-color:rgba(31,41,55,var(--tw-bg-opacity));
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }
</style>

<div class="hidden lg:flex flex-col w-20 py-6 shadow-md items-center space-y-8" id="sidebar">
        <a href="play-game.php" class="text-green-500 text-2xl">🏏</a>
        <a href="myleagues.php" class="text-gray-400 text-2xl">⭐</a>
        <a href="wallet.php" class="text-gray-400 text-2xl">💰</a>
        <a href="profile.php" class="text-gray-400 text-2xl">🙍‍♂️</a>
        <a href="more.php" class="text-gray-400 text-2xl">⋯</a>
    </div>