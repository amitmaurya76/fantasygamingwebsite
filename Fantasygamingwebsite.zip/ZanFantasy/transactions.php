<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Transactions - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
</head>
<body class="bg-gray-50 p-4">
    <div class="max-w-md mx-auto bg-white rounded-lg shadow p-4">
        <h2 class="text-xl font-bold mb-4">Transaction History</h2>
        <?php if ($transactions): ?>
            <div class="space-y-2 max-h-[70vh] overflow-y-auto">
                <?php foreach ($transactions as $txn): ?>
                    <div class="bg-gray-100 rounded p-3 flex justify-between items-center">
                        <div>
                            <div class="text-sm font-semibold"><?php echo htmlspecialchars($txn['mode']); ?> - <?php echo htmlspecialchars($txn['status']); ?></div>
                            <div class="text-xs text-gray-500"><?php echo htmlspecialchars($txn['created_at']); ?></div>
                        </div>
                        <div class="text-green-600 font-bold">₹<?php echo htmlspecialchars($txn['amount']); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="text-sm text-gray-500">No transactions found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
