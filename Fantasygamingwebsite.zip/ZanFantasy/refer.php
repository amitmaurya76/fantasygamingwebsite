<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Refer & Earn - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
<link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <!-- Tailwind -->
    <link href="css\tailwind.min.css" rel="stylesheet"/>


    <!-- Confetti for celebration -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>

    <style>
        body {
            background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
        }
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        .toast {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #10b981;
            color: white;
            padding: 10px 20px;
            border-radius: 9999px;
            font-size: 0.875rem;
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: 50;
        }
        .toast.show {
            opacity: 1;
        }
        .qr-hover:hover {
            transform: scale(1.05) rotate(2deg);
            transition: transform 0.4s ease;
        }
    </style>
</head>

<body class="bg-gray-50">

<?php include 'loader.php'; ?>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
            </div>

            <!-- Refer & Earn Card -->
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-6 text-gray-200 text-center">
                <h2 class="text-2xl font-bold mb-4">🎁 Refer & Earn</h2>
                <p class="text-sm mb-3">Invite your friends and earn rewards when they join Zanthium.</p>

                <!-- QR Code -->
                <div class="flex justify-center mb-4">
                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://zanthium.com/referral/AMIT1234"
                         alt="Referral QR"
                         class=" shadow-lg qr-hover transition">
                </div>

                <!-- Referral Code -->
                <div id="referralCode"
                     class="bg-gray-900 rounded-lg p-3 font-mono text-xl text-green-400 tracking-widest mb-4 select-all cursor-pointer hover:bg-gray-800 transition"
                     onclick="copyReferralCode()">
                    AMIT1234
                </div>

                <button onclick="copyReferralCode()"
                        class="bg-green-500 hover:bg-green-600 active:bg-green-700 transition text-white px-6 py-2 rounded-full mb-4 shadow-lg">
                    📋 Copy Referral Code
                </button>

                <!-- Referral Stats -->
                <div class="grid grid-cols-2 gap-4 mt-4 mb-4">
                    <div class="bg-gray-900 rounded p-3">
                        <p class="text-xs text-gray-400">Invites Sent</p>
                        <p class="text-green-400 text-lg font-bold">12</p>
                    </div>
                    <div class="bg-gray-900 rounded p-3">
                        <p class="text-xs text-gray-400">Rewards Earned</p>
                        <p class="text-green-400 text-lg font-bold">₹1200</p>
                    </div>
                </div>

                <!-- Share Buttons -->
                <div class="flex justify-center space-x-3 mt-3">
                    <a href="https://wa.me/?text=Join%20Zanthium%20Fantasy%20using%20my%20referral%20code%20AMIT1234"
                       target="_blank"
                       class="bg-green-600 hover:bg-green-700 px-3 py-1 rounded-full text-white text-sm transition shadow">
                        📱 WhatsApp
                    </a>
                    <a href="https://t.me/share/url?url=https://zanthium.com/referral/AMIT1234&text=Join%20Zanthium%20Fantasy%20with%20my%20referral%20code"
                       target="_blank"
                       class="bg-blue-500 hover:bg-blue-600 px-3 py-1 rounded-full text-white text-sm transition shadow">
                        ✈️ Telegram
                    </a>
                    <a href="sms:?body=Join%20Zanthium%20Fantasy%20using%20my%20referral%20code%20AMIT1234"
                       target="_blank"
                       class="bg-gray-600 hover:bg-gray-700 px-3 py-1 rounded-full text-white text-sm transition shadow">
                        ✉️ SMS
                    </a>
                </div>

                <p class="text-xs text-gray-300 mt-3">Share your code and earn <span class="text-green-400 font-semibold">₹100</span> on your friend's first deposit.</p>
            </div>

            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>
    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<!-- Toast Notification -->
<div id="toast" class="toast">Referral code copied!</div>

<!-- Scripts -->
<script>
function copyReferralCode() {
    const code = "AMIT1234";
    navigator.clipboard.writeText(code).then(() => {
        if (typeof confetti === "function") {
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 }
            });
        }
        showToast();
    });
}
function showToast() {
    const toast = document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2000);
}
</script>

</body>
</html>
