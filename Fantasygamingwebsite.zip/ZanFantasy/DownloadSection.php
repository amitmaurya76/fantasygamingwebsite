<style>
      /* Ensure rounded edges and clean scaling */
img.rounded-xl {
    border-radius: 1rem;
}

.shadow-xl {
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6);
}

.hover\\:scale-105:hover {
    transform: scale(1.05);
}

.transition-transform {
    transition: transform 0.3s ease;
}

/* For ultra-large screens */
@media (min-width: 1536px) {
    .lg\\:w-96 {
        width: 28rem;
    }
}

@media (min-width: 2560px) {
    .lg\\:w-96 {
        width: 32rem;
    }
}

@media (min-width: 3840px) {
    .lg\\:w-96 {
        width: 46rem;
    }
}

</style>
<div class="hidden lg:flex flex-col justify-center items-center p-4 w-full lg:w-96">
      <img src="image/appui.png" alt="Player" class="h-3/5 w-full mb-4 rounded" />
      <h2 class="text-xl font-bold text-center text-gray-50">Play Zanthium Fantasy on Mobile</h2>
      <div class="flex mt-4 space-x-2 justify-center">
       <a href="https://play.google.com/store/apps" target="_blank" rel="noopener">
       <img src="image/image.png" alt="Download on Google Play" class="w-28 rounded hover:scale-105 transition-transform duration-300 shadow-lg" />
       </a>
        <a href="https://apps.apple.com/app" target="_blank" rel="noopener">
        <img src="image/image1.png" alt="Download on App Store" class="w-28 rounded hover:scale-105 transition-transform duration-300 shadow-lg" />
        </a>
      </div>

</div>