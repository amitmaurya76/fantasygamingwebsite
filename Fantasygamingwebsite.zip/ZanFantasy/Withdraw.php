<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Withdraw - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <link href="css\tailwind.min.css" rel="stylesheet"/>
    <style>
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.2);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
            background: #0f172a;
        }
        #sidebar a:hover {
            background: black;
            font-size: 2rem;
            line-height: 2rem;
            border-radius: 50px;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-800 to-gray-900 min-h-screen">

<?php include 'loader.php'; ?>

<div class="flex flex-col lg:flex-row min-h-screen">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 flex justify-center items-center p-4">
        <div class="max-w-md w-full bg-gradient-to-r from-gray-800 to-gray-700 rounded-3xl shadow-lg p-6 border border-gray-700">

            <div class="flex justify-center mb-4">
                <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12 object-contain" />
            </div>

            <h2 class="text-xl font-bold text-center text-white mb-4">💸 Withdraw Cash</h2>

            <div class="bg-gray-900 rounded-lg p-4 mb-4 text-gray-200 space-y-1">
                <div class="flex justify-between">
                    <span>Withdrawable Balance:</span>
                    <span class="font-semibold text-green-400">₹5,000</span>
                </div>
                <div class="flex justify-between">
                    <span>Pending Withdrawals:</span>
                    <span class="font-semibold text-yellow-400">₹0</span>
                </div>
            </div>

            <input type="number" placeholder="Enter withdrawal amount" class="w-full mb-4 p-3 rounded-lg bg-gray-800 text-white border border-gray-600 focus:outline-none focus:ring-2 focus:ring-green-400" />

            <div class="grid grid-cols-4 gap-2 mb-4">
                <button class="bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg" onclick="document.querySelector('input[type=number]').value=100;">₹100</button>
                <button class="bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg" onclick="document.querySelector('input[type=number]').value=500;">₹500</button>
                <button class="bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg" onclick="document.querySelector('input[type=number]').value=1000;">₹1000</button>
                <button class="bg-gray-800 hover:bg-gray-700 text-white py-2 rounded-lg" onclick="document.querySelector('input[type=number]').value=1500;">₹1500</button>
            </div>

            <a href="coming_soon2.php">
                <button class="w-full bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-semibold transition">Withdraw Now</button>
            </a>
            <p class="text-xs text-gray-400 text-center mt-2">Withdrawals are processed within 24-48 hours to your linked bank/UPI.</p>
        </div>
    </div>
</div>

<?php include 'bottom_nav.php'; ?>

</body>
</html>
