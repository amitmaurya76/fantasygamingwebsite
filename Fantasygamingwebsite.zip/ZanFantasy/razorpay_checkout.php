<?php
session_start();
require 'razorpay/Razorpay.php';

use Razorpay\Api\Api;

if (!isset($_SESSION['razorpay_order_id'])) {
    header("Location: payment_failed.php?reason=Session expired");
    exit();
}

$order_id = $_SESSION['razorpay_order_id'];
$entry_fee = $_SESSION['entry_fee'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Complete Payment - Zanthium</title>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</head>
<body>
<script>
var options = {
    "key": "rzp_test_yourkey",
    "amount": "<?php echo $entry_fee * 100; ?>",
    "currency": "INR",
    "name": "Zanthium Fantasy",
    "description": "Contest Entry Fee",
    "order_id": "<?php echo $order_id; ?>",
    "handler": function (response){
        window.location.href = "razorpay_callback.php?payment_id=" + response.razorpay_payment_id + "&order_id=" + response.razorpay_order_id;
    },
    "theme": {
        "color": "#10B981"
    }
};
var rzp1 = new Razorpay(options);
rzp1.open();
</script>
</body>
</html>
