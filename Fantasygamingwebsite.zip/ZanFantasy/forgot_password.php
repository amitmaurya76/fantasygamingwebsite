<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #1d3138, #2c5364, #000000);
        }
        .card {
            background: linear-gradient(135deg, #1d3138, #2c5364, #000000);
            border-radius: 1rem;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
            border:1px solid rgb(64, 98, 112);
        }
        .input {
            background:  #2c5364;
            border: 1px solid #d1d5db;
            transition: all 0.3s ease;
        }
        .input:focus {
            border-color: #22c55e;
            box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.3);
        }
        .button {
            background: linear-gradient(to right, #22c55e, #16a34a);
            transition: all 0.3s ease;
        }
        .button:hover {
            background: linear-gradient(to right, #16a34a, #15803d);
            transform: translateY(-1px);
        }
        @keyframes fade-in {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
            animation: fade-in 0.6s ease-out;
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen relative">

<div class="card p-6 w-full max-w-sm mx-4 animate-fade-in">
    <div class="flex justify-center mb-4">
        <img src="image/logo-white.png" alt="Zanthium Logo" class="h-12">
    </div>
    <h2 class="text-center text-2xl font-bold text-gray-50 mb-1">Forgot Password</h2>
    <p class="text-center text-sm text-gray-50 mb-4">Enter your email or mobile to reset your password.</p>

    <?php session_start(); if (isset($_SESSION['error'])) { ?>
        <p class="text-red-500 text-sm text-center mb-2">
            <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
        </p>
    <?php } ?>

    <form action="index.php" method="POST" class="space-y-4">
        <input 
            type="text" 
            name="email" 
            placeholder="Email or Mobile" 
            required 
            class="input w-full px-3 py-2 rounded focus:outline-none"
        >
        <button 
            type="submit" 
            class="button w-full text-white font-semibold py-2 rounded shadow"
        >
            🔒 Reset Password
        </button>
    </form>

    <p class="text-xs text-gray-50 text-center mt-3">
        Remembered your password? 
        <a href="login.php" class="text-green-600 hover:underline">Login</a>
    </p>
</div>

</body>
</html>
