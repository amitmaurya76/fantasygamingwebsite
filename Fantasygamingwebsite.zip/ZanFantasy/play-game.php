<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Zanthium - Home of Fantasy Sports</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
    <link href="css/tailwind.min.css" rel="stylesheet"/>
  <link href="css/style.css" rel="stylesheet" />
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
</head>
<body>
  <style>
    #sidebar {
      height: 400px;
      border: 2px solid rgba(240, 248, 255, 0.65);
      border-radius: 40px;
      margin: 10% 10px;
      justify-content: center;
      background-color:black;
    }
    #sidebar a:hover {
      border-radius: 50px;
      background: black;
      font-size: 2rem;
      line-height: 2rem;
    }
  </style>
<?php include 'loader.php'; ?>


<div class="flex flex-col lg:flex-row min-h-screen">
  
  <!-- Sidebar -->
  <div class="hidden lg:flex flex-col w-20 py-6 shadow-md items-center space-y-8" id="sidebar">
        <a href="play-game.php" class="text-green-500 text-2xl">🏏</a>
        <a href="myleagues.php" class="text-gray-400 text-2xl">⭐</a>
        <a href="wallet.php" class="text-gray-400 text-2xl">💰</a>
        <a href="profile.php" class="text-gray-400 text-2xl">🙍‍♂️</a>
        <a href="more.php" class="text-gray-400 text-2xl">⋯</a>
    </div>

  <!-- Main Content -->
  <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

      <!-- Logo -->
      <div class="w-full h-12 mb-4 flex items-center justify-center">
        <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
      </div>

      <!-- Slider -->
      <div class="relative overflow-hidden rounded-xl aspect-video mb-4">
        <div class="flex transition-transform duration-500 ease-in-out" id="sliderTrack">
          <img src="image/banner1.png" class="w-full flex-shrink-0 object-cover" alt="Banner 1" />
          <img src="image/banner2.png" class="w-full flex-shrink-0 object-cover" alt="Banner 2" />
          <img src="image/banner3.png" class="w-full flex-shrink-0 object-cover" alt="Banner 3" />
        </div>
      </div>

      <!-- Tabs -->
      <div class="flex justify-between mb-4">
        <button class="tab-btn flex-1 py-2 text-center bg-green-600 text-white rounded-l" data-tab="cricket">Cricket</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white" data-tab="football">Football</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white" data-tab="basketball">Basketball</button>
        <button class="tab-btn flex-1 py-2 text-center bg-gray-600 text-white rounded-r" data-tab="kabaddi">Kabaddi</button>
      </div>

      <!-- Matches -->
      <div id="cricket" class="tab-content space-y-3">
        <?php for ($i = 0; $i < 2; $i++) { ?>
          <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4">
            <div class="flex justify-between items-center mb-2">
              <span class="text-xs text-green-300">Upcoming</span>
              <span class="text-xs text-gray-300">Champions League</span>
            </div>
            <div class="flex justify-between items-center">
              <div class="flex flex-col items-center">
                <img src="image/team1.png" alt="Team A" class="w-12 h-12 object-contain" />
                <span class="text-xs mt-1 text-gray-200">TEAM A</span>
              </div>
              <div class="text-center">
                <span class="block text-xs text-gray-400">Time Left</span>
                <span class="text-green-400 font-bold countdown">Loading...</span>
              </div>
              <div class="flex flex-col items-center">
                <img src="image/team2.png" alt="Team B" class="w-12 h-12 object-contain" />
                <span class="text-xs mt-1 text-gray-200">TEAM B</span>
              </div>
            </div>
            <div class="flex justify-center mt-2">
              <a href="contests.php" class="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded text-xs">Join Contest</a>
            </div>
          </div>
        <?php } ?>
      </div>

      <!-- Football Tab -->
<div id="football" class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4 tab-content hidden flex flex-col justify-center items-center min-h-[40vh] text-white space-y-4">
    <img src="image/404-player.png" alt="No Football Matches" class="w-28 h-28 ">
    <p class="text-lg font-semibold text-gray-200">No Football Matches Available</p>
    <p class="text-sm text-gray-400 text-center max-w-xs">Stay tuned! Football matches will appear here once available for you to join and play.</p>
</div>

<!-- Basketball Tab -->
<div id="basketball" class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4 tab-content hidden flex flex-col justify-center items-center min-h-[40vh] text-white space-y-4">
    <img src="image/404-player.png" alt="No Basketball Matches" class="w-28 h-28 ">
    <p class="text-lg font-semibold text-gray-200">No Basketball Matches Available</p>
    <p class="text-sm text-gray-400 text-center max-w-xs">Stay tuned! Basketball matches will appear here once available for you to join and play.</p>
</div>

<!-- Kabaddi Tab -->
<div id="kabaddi" class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4 tab-content hidden flex flex-col justify-center items-center min-h-[40vh] text-white space-y-4">
    <img src="image/404-player.png" alt="No Kabaddi Matches" class="w-28 h-28 ">
    <p class="text-lg font-semibold text-gray-200">No Kabaddi Matches Available</p>
    <p class="text-sm text-gray-400 text-center max-w-xs">Stay tuned! Kabaddi matches will appear here once available for you to join and play.</p>
</div>

      <!-- Load More Button -->
      <div class="flex justify-center mt-4">
        <button id="loadMoreBtn" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition text-sm">Load More</button>
      </div>

    </div>

    <?php include 'DownloadSection.php'; ?>
  </div>
</div>

<?php include 'bottom_nav.php'; ?>

<script>
// Slider
const sliderTrack = document.getElementById('sliderTrack');
const slides = sliderTrack.children;
let currentIndex = 0;
setInterval(() => {
  currentIndex = (currentIndex + 1) % slides.length;
  sliderTrack.style.transform = `translateX(-${currentIndex * 100}%)`;
}, 3000);

// Tabs
const tabBtns = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');
tabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    tabBtns.forEach(b => b.classList.replace('bg-green-600', 'bg-gray-600'));
    btn.classList.replace('bg-gray-600', 'bg-green-600');
    tabContents.forEach(tc => tc.classList.add('hidden'));
    document.getElementById(btn.dataset.tab).classList.remove('hidden');
  });
});

// Countdown
document.querySelectorAll('.countdown').forEach((el, idx) => {
  let totalSeconds = 3600 + idx * 60;
  setInterval(() => {
    if (totalSeconds <= 0) {
      el.textContent = 'Started';
      el.classList.replace('text-green-400', 'text-red-500');
      return;
    }
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    el.textContent = `${m}m ${s}s`;
    totalSeconds--;
  }, 1000);
});

// Load More
document.getElementById('loadMoreBtn').addEventListener('click', () => {
  const container = document.getElementById('cricket');
  const card = document.createElement('div');
  card.className = 'bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-4';
  card.innerHTML = `
    <div class="flex justify-between items-center mb-2">
      <span class="text-xs text-green-300">Upcoming</span>
      <span class="text-xs text-gray-300">Champions League</span>
    </div>
    <div class="flex justify-between items-center">
      <div class="flex flex-col items-center">
        <img src="image/team3.png" alt="Team X" class="w-12 h-12 object-contain" />
        <span class="text-xs mt-1 text-gray-200">TEAM X</span>
      </div>
      <div class="text-center">
        <span class="block text-xs text-gray-400">Time Left</span>
        <span class="text-green-400 font-bold countdown">Loading...</span>
      </div>
      <div class="flex flex-col items-center">
        <img src="image/team4.png" alt="Team Y" class="w-12 h-12 object-contain" />
        <span class="text-xs mt-1 text-gray-200">TEAM Y</span>
      </div>
    </div>
    <div class="flex justify-center mt-2">
      <a href="contests.php" class="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded text-xs">Join Contest</a>
    </div>`;
  container.appendChild(card);
  const countdownEl = card.querySelector('.countdown');
  let totalSeconds = 3600;
  setInterval(() => {
    if (totalSeconds <= 0) {
      countdownEl.textContent = 'Started';
      countdownEl.classList.replace('text-green-400', 'text-red-500');
      return;
    }
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    countdownEl.textContent = `${m}m ${s}s`;
    totalSeconds--;
  }, 1000);
});
</script>

</body>
</html>
