<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Choose Captain & Vice-Captain - Zanthium</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">


<style>
.gradient-header { background: linear-gradient(90deg, #0f2027, #203a43, #2c5364); }
.selected { border: 2px solid #10b981; background-color: rgba(16, 185, 129, 0.1); }
#sidebar {
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
#sidebar a:hover {
  border-radius: 50px;
  background: black;
  font-size: 2rem;
  line-height: 2rem;
}
body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col lg:flex-row">
<?php include 'loader.php'; ?>

<!-- Sidebar -->
    <?php include 'sidebar.php'; ?>


<!-- Main Content -->
<div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
  <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >

    <!-- Logo -->
    <div class="w-full h-12 mb-4 flex items-center justify-center">
      <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
    </div>

    <!-- Match Header -->
    <div class="gradient-header p-4 rounded-lg text-white flex justify-between items-center mb-4">
      <div class="flex items-center space-x-4">
        <div class="flex flex-col items-center">
          <img src="image/team1.png" alt="WLS" class="w-12 h-12 rounded-full border border-white">
          <span class="text-xs">Team 1</span>
        </div>
        <span>vs</span>
        <div class="flex flex-col items-center">
          <img src="image/team2.png" alt="CBR" class="w-12 h-12 rounded-full border border-white">
          <span class="text-xs">Team 2</span>
        </div>
      </div>
      <div class="text-center">
        <span class="block text-xs text-gray-300">Time Left</span>
        <span id="countdown" class="text-green-400 font-bold">0h 9m</span>
      </div>
    </div>

    <!-- Instruction Bar -->
    <div class="bg-gray-800 text-center rounded-lg p-2 font-semibold text-white text-sm mb-4">
      Tap to select your Captain and Vice-Captain
    </div>

    <!-- Player List -->
    <div id="playerList" class="space-y-2"></div>

    <!-- Confirm Button -->
    <button id="confirmBtn" disabled class="mt-4 w-full py-2 bg-green-600 hover:bg-green-700 rounded text-white font-bold">
      Save Team
    </button>

  </div>

  <!-- Right Download Section (Desktop) -->
     <?php include 'DownloadSection.php'; ?>

</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
const players = [
  { id: 1, name: 'Player 1', role: 'BAT', image: 'image/player1.png' },
  { id: 2, name: 'Player 2', role: 'WK', image: 'image/player2.png' },
  { id: 3, name: 'Player 3', role: 'AR', image: 'image/player3.png' },
  { id: 4, name: 'Player 4', role: 'BOWL', image: 'image/player4.png' },
  { id: 5, name: 'Player 5', role: 'BAT', image: 'image/player5.png' },
  { id: 6, name: 'Player 6', role: 'AR', image: 'image/player6.png' },
  { id: 7, name: 'Player 7', role: 'WK', image: 'image/player7.png' },
  { id: 8, name: 'Player 8', role: 'BOWL', image: 'image/player8.png' },
  { id: 9, name: 'Player 9', role: 'BAT', image: 'image/player9.png' },
  { id: 10, name: 'Player 10', role: 'AR', image: 'image/player10.png' },
  { id: 11, name: 'Player 11', role: 'BOWL', image: 'image/player11.png' }
];

const playerList = document.getElementById('playerList');
const confirmBtn = document.getElementById('confirmBtn');
let captain = null;
let viceCaptain = null;

function renderPlayers() {
  playerList.innerHTML = '';
  players.forEach(player => {
    const card = document.createElement('div');
    card.className = `bg-gray-800 rounded p-3 flex items-center justify-between cursor-pointer border transition ${
      captain === player.id ? 'border-yellow-400' :
      viceCaptain === player.id ? 'border-blue-400' :
      'border-gray-700'
    }`;
    card.innerHTML = `
      <div class="flex items-center space-x-3">
        <img src="${player.image}" alt="${player.name}" class="w-10 h-10 rounded-full border border-gray-700">
        <div>
          <p class="font-semibold text-sm text-white">${player.name}</p>
          <p class="text-xs text-gray-400">${player.role}</p>
        </div>
      </div>
      <div class="text-xs">
        ${captain === player.id ? '<span class="bg-yellow-500 px-2 py-1 rounded">Captain</span>' :
        viceCaptain === player.id ? '<span class="bg-blue-500 px-2 py-1 rounded">Vice-Captain</span>' :
        '<span class="text-gray-400">Tap to Select</span>'}
      </div>
    `;
    card.addEventListener('click', () => handleSelection(player.id));
    playerList.appendChild(card);
  });
  confirmBtn.disabled = !(captain && viceCaptain);
}

function handleSelection(playerId) {
  if (captain === null) {
    captain = playerId;
  } else if (viceCaptain === null && playerId !== captain) {
    viceCaptain = playerId;
  } else if (captain === playerId) {
    captain = null;
  } else if (viceCaptain === playerId) {
    viceCaptain = null;
  } else {
    alert('You can only select one Captain and one Vice-Captain. Tap to deselect to change.');
  }
  renderPlayers();
}

confirmBtn.addEventListener('click', () => {
  alert(`Captain: ${players.find(p => p.id === captain).name}\nVice-Captain: ${players.find(p => p.id === viceCaptain).name}`);
  window.location.href = 'myteam.php';
});

renderPlayers();
</script>
<script>
// Countdown Timer
let countdownSeconds = 9 * 60;
const countdownEl = document.getElementById('countdown');
const interval = setInterval(() => {
  if (countdownSeconds <= 0) {
    clearInterval(interval);
    countdownEl.textContent = 'Started';
    return;
  }
  const m = Math.floor(countdownSeconds / 60);
  const s = countdownSeconds % 60;
  countdownEl.textContent = `${m}m ${s}s`;
  countdownSeconds--;
}, 1000);
</script>
</body>
</html>
