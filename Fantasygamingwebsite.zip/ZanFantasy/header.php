<!-- header.php -->
<nav class="flex justify-between items-center p-4 bg-gray-800 shadow fixed top-0 w-full z-50">
    <div class="flex items-center space-x-2">
        <img src="image/logo-white.png" alt="Logo" class="rounded w-28" />
    </div>
    <div class="hidden md:flex space-x-6">
        <a href="index.php" class="hover:text-yellow-400 transition">Home</a>
        <a href="about-page.php" class="hover:text-yellow-400 transition">About</a>
        <a href="blog-page.php" class="hover:text-yellow-400 transition">Blog</a>
        <a href="how-to-play.php" class="hover:text-yellow-400 transition">How to Play</a>
        <a href="career.php" class="hover:text-yellow-400 transition">Career</a>
    </div>
    <div class="md:hidden">
        <button id="menu-button" class="text-white focus:outline-none">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>
        </button>
    </div>
    <a href="play-game.php" class="hidden md:inline bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition">Play Now</a>
</nav>

<!-- Mobile Menu -->
<div id="mobile-menu" class="fixed top-16 right-4 bg-gray-800 rounded shadow-lg p-4 flex flex-col space-y-4 z-50 hidden">
    <a href="index.php" class="hover:text-yellow-400 transition">Home</a>
    <a href="about-page.php" class="hover:text-yellow-400 transition">About</a>
    <a href="blog-page.php" class="hover:text-yellow-400 transition">Blog</a>
    <a href="how-to-play.php" class="hover:text-yellow-400 transition">How to Play</a>
    <a href="career.php" class="hover:text-yellow-400 transition">Career</a>
    <a href="play-game.php" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded transition">Play Now</a>
</div>

<script>
    const menuButton = document.getElementById('menu-button');
    const mobileMenu = document.getElementById('mobile-menu');

    menuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('hidden');
    });
</script>


