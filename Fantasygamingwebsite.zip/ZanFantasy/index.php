<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Zanthium - Home of Fantasy Sports</title>
    <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Roboto', sans-serif; }
    </style>
</head>
<body class="bg-gray-900 text-white min-h-screen flex flex-col">
    <?php include 'header.php'; ?>

    <!-- Hero Section -->
    <section class="relative flex flex-col items-center justify-center text-center py-32 px-4 bg-cover bg-center" style="background-image: url('image/background-image.png');">
        <div class="bg-black bg-opacity-70 p-8 rounded-xl w-full mx-auto">
            <h1 class="text-4xl md:text-6xl font-extrabold leading-tight">ZANTHIUM <span class="text-yellow-400">FANTASY SPORTS</span></h1>
            <p class="mt-4 text-lg md:text-xl">Create your team, join contests, and win real cash while enjoying your favourite sports leagues.</p>
            <div class="flex justify-center mt-6">
                <img src="image/appui.png" alt="App Screenshot" class="rounded-xl shadow-lg   " />
            </div>
            <div class="flex flex-col md:flex-row items-center justify-center mt-6 space-y-4 md:space-y-0 md:space-x-4">
                <a href="#download" class="bg-green-600 hover:bg-green-700  rounded flex items-center space-x-2 transition ">
                    <img src="image/image.png" alt="Google Play" class="h-8 rounded">
                    <!-- <span>Get it on Google Play</span> -->
                </a>
                <a href="#download" class="bg-gray-200 hover:bg-gray-300 text-black  rounded flex items-center space-x-2 transition">
                    <img src="image/image1.png" alt="Apple Store" class="h-8 rounded">
                    <!-- <span>Download on Apple Store</span> -->
                </a>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-16 px-4 text-center bg-gray-800">
        <h2 class="text-3xl font-bold mb-4">About Zanthium</h2>
        <p class="max-w-2xl mx-auto text-gray-300">Zanthium is your one-stop platform for fantasy sports, offering a seamless, competitive, and rewarding experience across multiple sports including cricket, football, and basketball. Build your team and compete in real-time contests.</p>
    </section>

    <!-- Blog Preview -->
    <section id="blog" class="py-16 px-4 text-center bg-gray-900">
        <h2 class="text-3xl font-bold mb-8">From Our Blog</h2>
        <div class="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <div class="bg-gray-800 p-4 rounded shadow hover:shadow-lg transition">
                <h3 class="text-xl font-semibold mb-2">Top Fantasy Picks This Season</h3>
                <p class="text-gray-400">Explore the top players you should add to your fantasy team for maximum points and performance.</p>
            </div>
            <div class="bg-gray-800 p-4 rounded shadow hover:shadow-lg transition">
                <h3 class="text-xl font-semibold mb-2">How to Win Big on Zanthium</h3>
                <p class="text-gray-400">Tips and strategies to enhance your gameplay and increase your chances of winning in contests.</p>
            </div>
            <div class="bg-gray-800 p-4 rounded shadow hover:shadow-lg transition">
                <h3 class="text-xl font-semibold mb-2">Upcoming Tournaments to Join</h3>
                <p class="text-gray-400">Stay updated with upcoming leagues and tournaments where you can compete and win cash rewards.</p>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section id="play" class="py-16 px-4 text-center bg-blue-700">
        <h2 class="text-3xl font-bold mb-4">Ready to Play and Win?</h2>
        <p class="max-w-xl mx-auto mb-6">Join Zanthium now, start building your fantasy teams, and stand a chance to win real cash rewards while enjoying your favourite sports.</p>
        <a href="play-game.php" class="bg-yellow-400 hover:bg-yellow-500 text-black px-6 py-3 rounded text-lg font-semibold transition">Play Now</a>
    </section>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

</body>
</html>
