<!-- loader.php -->
<style>
.loader-overlay {
    position: fixed;
    inset: 0;
    background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 50;
}

.loader {
    width: 30px;
    aspect-ratio: 1;
    display: grid;
    transform: translateY(100%);
}

.loader::before,
.loader::after {
    content: "";
    grid-area: 1/1;
    border-radius: 50%;
    transform-origin: bottom;
    position: relative;
}

.loader::before {
    background: radial-gradient(at 30% 30%, #0000, #000a) red;
    transform: scaleY(0.65);
    top: 0;
    animation: l11-1 2s cubic-bezier(0,400,1,400) infinite,
               l11-2 2s ease infinite;
}

.loader::after {
    background: #ccc;
    filter: blur(8px);
    transform: scaleY(0.3) translate(0px,0px);
    left: 0;
    animation: l11-3 2s cubic-bezier(0,400,1,400) infinite;
}

@keyframes l11-1 { 100% { top: -0.2px } }
@keyframes l11-2 { 4%,96% { transform: scaleY(1) } }
@keyframes l11-3 { 100% { transform: scaleY(0.3) translate(0.1px, -0.1px) } }
</style>

<div id="loaderOverlay" class="loader-overlay">
    <div class="loader"></div>
</div>

<script>
window.addEventListener('load', () => {
    const loader = document.getElementById('loaderOverlay');
    if(loader){
        loader.style.opacity = '0';
        loader.style.transition = 'opacity 0.5s ease';
        setTimeout(() => loader.style.display = 'none', 500);
    }
});
</script>
