<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Contest Details - Zanthium</title>
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />
  <link href="css\tailwind.min.css" rel="stylesheet"/>
  <link rel="icon" href="image/favicon.ico" type="image/x-icon">

<style>
#sidebar {
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
#sidebar a:hover {
  border-radius: 50px;
  background: black;
  font-size: 2rem;
  line-height: 2rem;
}
body{
  background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
}

#sidebar{
  height: 400px;
  border: 2px solid rgba(240, 248, 255, 0.65);
  border-radius: 40px;
  margin: 10% 10px;
  justify-content: center;
}
.text-gray-50 {
  --tw-text-opacity:1;
  color:rgb(255, 255, 255);
}
.text-xs {
  font-size:.75rem;
  line-height:1rem;
  color: white;
}

.to-gray-700 {
  --tw-gradient-to:#2b5263;
}
.to-gray-800 {
  --tw-gradient-to:#1f2937
}

.rounded {
  border-radius:1.25rem;
}
</style>
</head>
<body class="bg-gray-50">
  <?php include 'loader.php'; ?>


<div class="flex flex-col lg:flex-row min-h-screen">

  <!-- Sidebar -->
      <?php include 'sidebar.php'; ?>


  <!-- Main Content -->
  <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
    <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile" >


      <!-- Logo -->
      <div class="w-full h-12 mb-4 flex items-center justify-center">
        <img src="image/logo-black.png" alt="logo" class="h-full object-contain" />
      </div>

      <!-- Match Header -->
      <div class="bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 p-4 rounded-lg text-white flex justify-between items-center mb-4">
        <div class="flex items-center space-x-4">
          <div class="flex flex-col items-center">
            <img src="image/team1.png" alt="KOL" class="w-12 h-12 rounded-full border border-white">
            <span class="text-xs">Team 1</span>
          </div>
          <span>vs</span>
          <div class="flex flex-col items-center">
            <img src="image/team2.png" alt="MI" class="w-12 h-12 rounded-full border border-white">
            <span class="text-xs">Team 2</span>
          </div>
        </div>
        <div class="text-center">
          <span class="block text-xs text-gray-300">Time Left</span>
          <span id="countdown" class="text-green-400 font-bold">0h 9m</span>
        </div>
      </div>

      <!-- Contest Info -->
      <div class="bg-gray-800 text-white rounded-lg p-4 mb-4">
        <p class="text-xs text-gray-400">PRIZE POOL</p>
        <p class="text-2xl font-bold">₹35 Crores</p>
        <p class="text-xs text-gray-400">95,23,589 spots left | Entry ₹49 | 1st Prize ₹2 Crores | 64% Winners | Up to 20 Teams | Guaranteed</p>
        <a href="payment.php">
          <button class="mt-3 w-full py-2 bg-green-600 hover:bg-green-700 rounded font-bold text-lg">JOIN ₹49</button>
        </a>
      </div>

      <!-- Tabs -->
      <div class="flex justify-around bg-gray-100 rounded-lg mb-4 text-sm">
        <button id="winningsTab" class="py-2 flex-1 text-center font-semibold border-b-2 border-green-600 text-green-600">Winnings</button>
        <button id="leaderboardTab" class="py-2 flex-1 text-center font-semibold text-gray-600">Leaderboard</button>
      </div>

      <!-- Tab Content: Winnings -->
<div id="winningsContent" class="bg-white rounded-2xl shadow p-4 space-y-3">

    <h3 class="text-center font-semibold text-gray-700 mb-2">🏆 Prize Distribution</h3>

    <!-- Winnings List -->
    <div class="space-y-2">
        <div class="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
            <span class="text-yellow-500 font-bold">🥇 1st Place</span>
            <span class="text-green-600 font-bold">₹2 Crores</span>
        </div>
        <div class="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
            <span class="text-gray-500 font-bold">🥈 2nd Place</span>
            <span class="text-green-600 font-bold">₹40 Lakhs</span>
        </div>
        <div class="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
            <span class="text-orange-500 font-bold">🥉 3rd Place</span>
            <span class="text-green-600 font-bold">₹10 Lakhs</span>
        </div>
        <div class="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
            <span class="text-gray-700 font-medium">4th Place</span>
            <span class="text-green-600 font-bold">₹5 Lakhs</span>
        </div>
        <div class="flex items-center justify-between bg-gray-50 p-2 rounded-lg shadow-sm">
            <span class="text-gray-700 font-medium">5th Place</span>
            <span class="text-green-600 font-bold">₹1.5 Lakhs</span>
        </div>
    </div>

</div>


      <!-- Tab Content: Leaderboard -->
<div id="leaderboardContent" class="bg-white rounded-2xl shadow p-4 space-y-3 hidden">

    <h3 class="text-center font-semibold text-gray-700 mb-2">📈 Leaderboard</h3>

    <!-- Leaderboard Header -->
    <div class="grid grid-cols-3 text-sm font-semibold text-gray-500 border-b pb-2">
        <span>User</span>
        <span class="text-center">Points</span>
        <span class="text-right">Rank</span>
    </div>

    <!-- Leaderboard Entries -->
    <div class="space-y-2">
        <div class="grid grid-cols-3 items-center bg-gray-50 p-2 rounded-lg shadow-sm text-sm">
            <div class="flex items-center space-x-1">
                <img src="image/user/user1.jpg" alt="User" class="w-5 h-5 rounded-full">
                <span class="truncate">kehda jam peyaa s...(T6)</span>
            </div>
            <span class="text-center">695.5</span>
            <span class="text-green-600 font-bold text-right">#1</span>
        </div>
        <div class="grid grid-cols-3 items-center bg-gray-50 p-2 rounded-lg shadow-sm text-sm">
            <div class="flex items-center space-x-1">
                <img src="image/user/user2.jpg" alt="User" class="w-5 h-5 rounded-full">
                <span class="truncate">Samba19(T2)</span>
            </div>
            <span class="text-center">678.5</span>
            <span class="text-green-600 font-bold text-right">#2</span>
        </div>
        <div class="grid grid-cols-3 items-center bg-gray-50 p-2 rounded-lg shadow-sm text-sm">
            <div class="flex items-center space-x-1">
                <img src="image/user/user3.jpg" alt="User" class="w-5 h-5 rounded-full">
                <span class="truncate">Farhan Force(T6)</span>
            </div>
            <span class="text-center">678</span>
            <span class="text-green-600 font-bold text-right">#3</span>
        </div>
        <div class="grid grid-cols-3 items-center bg-gray-50 p-2 rounded-lg shadow-sm text-sm">
            <div class="flex items-center space-x-1">
                <img src="image/user/user4.jpg" alt="User" class="w-5 h-5 rounded-full">
                <span class="truncate">ELWIN31IJ(T5)</span>
            </div>
            <span class="text-center">674</span>
            <span class="text-green-600 font-bold text-right">#4</span>
        </div>
        <div class="grid grid-cols-3 items-center bg-gray-50 p-2 rounded-lg shadow-sm text-sm">
            <div class="flex items-center space-x-1">
                <img src="image/user/user5.jpg" alt="User" class="w-5 h-5 rounded-full">
                <span class="truncate">kehda jam peyaa s...(T2)</span>
            </div>
            <span class="text-center">666.5</span>
            <span class="text-green-600 font-bold text-right">#5</span>
        </div>
    </div>

</div>



    </div>

    <!-- Right Download Section (Desktop) -->
        <?php include 'DownloadSection.php'; ?>

  </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

<script>
// Tabs toggle
document.getElementById('winningsTab').addEventListener('click', () => {
  document.getElementById('winningsTab').classList.add('border-green-600', 'text-green-600');
  document.getElementById('leaderboardTab').classList.remove('border-green-600', 'text-green-600');
  document.getElementById('leaderboardTab').classList.add('text-gray-600');
  document.getElementById('winningsContent').classList.remove('hidden');
  document.getElementById('leaderboardContent').classList.add('hidden');
});

document.getElementById('leaderboardTab').addEventListener('click', () => {
  document.getElementById('leaderboardTab').classList.add('border-green-600', 'text-green-600');
  document.getElementById('winningsTab').classList.remove('border-green-600', 'text-green-600');
  document.getElementById('winningsTab').classList.add('text-gray-600');
  document.getElementById('leaderboardContent').classList.remove('hidden');
  document.getElementById('winningsContent').classList.add('hidden');
});
</script>
<script>
// Countdown Timer
let countdownSeconds = 9 * 60;
const countdownEl = document.getElementById('countdown');
const interval = setInterval(() => {
  if (countdownSeconds <= 0) {
    clearInterval(interval);
    countdownEl.textContent = 'Started';
    return;
  }
  const m = Math.floor(countdownSeconds / 60);
  const s = countdownSeconds % 60;
  countdownEl.textContent = `${m}m ${s}s`;
  countdownSeconds--;
}, 1000);
</script>

</body>
</html>
