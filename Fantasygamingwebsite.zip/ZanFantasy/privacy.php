<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Privacy Policy - Zanthium</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="css\tailwind.min.css" rel="stylesheet"/>
    <link rel="icon" href="image/favicon.ico" type="image/x-icon">

    <style>
        body {
            background: linear-gradient(90deg, #487f958f, #1d3138, #2c53648c);
        }
        #sidebar {
            height: 400px;
            border: 2px solid rgba(240, 248, 255, 0.65);
            border-radius: 40px;
            margin: 10% 10px;
            justify-content: center;
        }
        #sidebar a:hover {
            border-radius: 50px;
            background: black;
            font-size: 2rem;
            line-height: 2rem;
        }
        .rounded {
            border-radius: 1.25rem;
        }
    </style>
</head>
<body class="bg-gray-50">

<?php include 'loader.php'; ?>

<!-- Wrapper -->
<div class="flex flex-col lg:flex-row min-h-screen">

    <!-- Sidebar (Desktop) -->
        <?php include 'sidebar.php'; ?>


    <!-- Main Content -->
    <div class="flex-1 flex flex-col lg:flex-row h-screen justify-center overflow-hidden">
        <div class="flex-1 p-4 max-w-2xl mx-auto bg-gray-50 overflow-y-auto main-content-mobile">

            <!-- Logo -->
            <div class="w-full h-12 mb-4 flex items-center">
                <img src="image/logo-black.png" alt="Logo" class="h-full object-contain">
            </div>

            <!-- Privacy Policy Card -->
            <div class="bg-gradient-to-r from-gray-800 to-gray-700 rounded-lg shadow p-6 text-gray-200 text-sm max-h-[70vh] overflow-y-auto">
                <h2 class="text-xl font-bold text-center mb-4">🔒 Privacy Policy</h2>

                <h3 class="text-green-400 font-semibold mb-1">1️⃣ Data Collection</h3>
                <p class="mb-2">We collect essential personal details such as your name, email, and contact number to provide a seamless gameplay experience.</p>

                <h3 class="text-green-400 font-semibold mb-1">2️⃣ Usage of Information</h3>
                <p class="mb-2">Your data is used to enhance gameplay, manage your account, process transactions, and provide personalized content and support.</p>

                <h3 class="text-green-400 font-semibold mb-1">3️⃣ Data Security</h3>
                <p class="mb-2">Your data is stored securely on our encrypted servers and we do not share your personal information with third parties without your consent.</p>

                <h3 class="text-green-400 font-semibold mb-1">4️⃣ Contact Us</h3>
                <p class="mb-2">For queries related to your privacy, please contact:</p>
                <p class="text-green-400 font-semibold mb-2">support@zanthium.com</p>
                <p class="text-green-400 font-semibold mb-2">+91 94589 02989</p>

                <p class="text-xs text-gray-300 text-center mt-3">Your trust is important to us, and we are committed to protecting your privacy while you enjoy Zanthium Fantasy.</p>
            </div>

            <!-- Mobile Download Prompt -->
            <div class="lg:hidden bg-gray-200 rounded-lg p-4 mt-6 text-center">
                <h2 class="text-lg font-bold">Play Zanthium Fantasy</h2>
                <div class="flex justify-center mt-2 space-x-2">
                    <img src="image/image.png" alt="Download Android" class="w-24">
                    <img src="image/image1.png" alt="Download iOS" class="w-24">
                </div>
            </div>
        </div>

        <!-- Right Player Image Section -->
        <?php include 'DownloadSection.php'; ?>

    </div>
</div>

<!-- Bottom Navigation -->
<?php include 'bottom_nav.php'; ?>

</body>
</html>
