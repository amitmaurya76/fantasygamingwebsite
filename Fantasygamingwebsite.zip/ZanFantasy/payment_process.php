<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$entry_fee = 49; // Amount to deduct
$mode = "Wallet";

// Fetch user wallet
$stmt = $pdo->prepare("SELECT wallet FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: payment_failed.php?reason=User not found");
    exit();
}

$wallet_balance = $user['wallet'];

if ($wallet_balance >= $entry_fee) {
    // Deduct from wallet
    $pdo->prepare("UPDATE users SET wallet = wallet - ? WHERE id = ?")->execute([$entry_fee, $user_id]);

    // Log transaction
    $pdo->prepare("INSERT INTO transactions (user_id, amount, mode, status, created_at) VALUES (?, ?, ?, ?, NOW())")
        ->execute([$user_id, $entry_fee, $mode, 'Success']);

    header("Location: payment_success.php?amount=$entry_fee&mode=Wallet");
    exit();
} else {
    // Insufficient balance, fallback to Razorpay
    require 'razorpay/Razorpay.php';
    use Razorpay\Api\Api;

    $api = new Api('rzp_test_yourkey', 'your_secret');

    $order = $api->order->create([
        'amount' => $entry_fee * 100,
        'currency' => 'INR',
        'payment_capture' => 1
    ]);

    $_SESSION['razorpay_order_id'] = $order['id'];
    $_SESSION['entry_fee'] = $entry_fee;

    // Redirect to Razorpay Checkout
    header("Location: razorpay_checkout.php");
    exit();
}
?>
